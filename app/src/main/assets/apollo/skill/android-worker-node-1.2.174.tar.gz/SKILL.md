---
name: android-worker-node
description: >
  安卓数字营销运营数字员工。支持多种硬件平台：Radxa/泰山派（RK3576 开发板）、三星 Tab S9+（品牌 Pad）、白牌平板等。
  在 Termux 内运行，支持小红书/抖音/闲鱼等多平台自动化运营。
  包含：全自动发布、审批发布（飞书人工审核）、线索捕获（App内私信扫描为主 + 推送门铃）、赛道管理（生成/优化）。
  内置运营总监（每日分析 → 飞书审批）、营销总监（周报/月报 → 飞书推送）。
  LLM Wiki 知识系统：服务端拉取行业知识 → 本地 Markdown 维护 → 知识上报回流。
  附带 MQTT 远程管理旁路进程（mqtt-reporter），实现设备心跳上报、在线状态监控、配置远程下发、远程命令控制。
  设备通过 SN（设备编号）标识，SN 存储在 ~/.openclaw/mno_device.json（独立文件，不影响 openclaw.json）。
  触发词：安卓运营、安卓发布、安卓养号、手机运营、安卓小红书、安卓抖音、抖音发布、抖音养号、闲鱼发布、闲鱼挂、闲鱼上架、卖闲置、安卓闲鱼、通知监听、扫描私信、抓线索、看消息、抖音私信、闲鱼消息、回复私信、回复评论、截流、半自动回复、跟进线索、生成赛道、赛道优化、赛道分析、创建赛道、track、设备状态、设备管理、运营菜单、运营建议、运营分析、今天干什么、出个周报、出个月报、本周数据、wiki进化、同步知识库、配置定时任务、初始化设备、部署完成。
---

# 安卓数字营销运营数字员工

## ⚠️ 最重要的规则（不遵守就会出错！）

### 规则 1：直接运行命令，不要自己写代码
你**必须**运行下面的预设命令来完成任务。**禁止**你自己调用 LLM API、自己操作设备。pipeline.js 已经封装好了一切。

### 规则 2：必须指定赛道文件
每次运行都需要 `--track` 参数指向一个赛道 YAML 文件。赛道文件在 **本 skill 目录下的 `tracks/`**（设备上即 `…/skills/android-worker-node/tracks/`）。如果不确定用哪个赛道，先列出该目录下的文件。

> **注意**：`tracks/` 是运行时数据，不进 OTA 包，但 OTA 会保留。LLM/`generate.js` 首次生成会写入此目录并**尝试自动上传到云端**；若上传失败，管理端可对该设备执行「上传赛道到云端」。`tracks/` 为空时请提醒用户先生成或部署赛道。

> **舰队 AGENTS**：飞书群 Agent 读的是 workspace `AGENTS.md`，**不是**本 SKILL 长文。OTA 会把 `templates/AGENTS.fleet.md` 套过去（模板版本号升高才覆盖）并重启 OpenClaw；只升 skill / 只重启 OpenClaw 而手册仍是旧版时，Agent 会继续背「交给轮询」。群聊不会注入 `MEMORY.md`；发文/碰屏仍只跑本 skill 脚本。设备本地 `TOOLS.md` / `tracks/` 不被舰队覆盖。


### 规则 3：不要在凌晨运行
管线内置深夜保护，但你也不要在凌晨 0:00-7:00 之间主动运行任何操作命令。

### 规则 4：用户发了图片时，加 `--collect-images` 让管线自动下载

**你（Agent）无法直接把聊天中的图片保存到磁盘。** 所以关于图片处理，你只需要做一件事：

> 当用户在消息中发了图片，你在运行 pipeline 命令时**必须加上 `--collect-images`**。
> 管线会自动从飞书群聊下载用户**最近一批连续发送的图片**（默认回溯约 6 小时，按飞书消息时间，不看 Pad 时钟；相邻间隔过大则截断，避免扫进更早的废图），作为发布素材。用户可先发图再聊几句，不必赶在几分钟内下指令。

**同时，把用户关于内容和图片的所有要求都写进 `--instruction`**。管线会自动用 AI 解析指令，区分"内容创作方向"和"图片处理指令"。

#### `--instruction` 写法指南

`--instruction` **只放内容主题**（写什么）。张数、画面、实拍怎么处理、封面大字，分别走下面的参数，不要全塞进这一句。

```bash
# ✅ 内容主题进 --instruction；实拍处理走参数
node scripts/xhs/pipeline.js \
  --track tracks/xxx.yaml \
  --mode review \
  --collect-images \
  --instruction "介绍机构信息，做宣传，引导客户家长试听" \
  --image-actions "1:ai_cover;2:original" \
  --cover-text "春季招生"

# ✅ 也可以只有内容方向（没有图片指令也行）
node scripts/douyin/pipeline.js \
  --track tracks/xxx.yaml \
  --mode review \
  --instruction "科技特长生政策科普"

# ✅ 没有特别要求就不加 --instruction，管线自动选主题
node scripts/xhs/pipeline.js --track tracks/xxx.yaml --mode review
```

`--instruction` 仍会解析风格、原文发布（`【标题】`+`【正文】`）。**不要指望它把「第一张做封面」传给叠字/出图模型。**

> **⚠️ 严重警告**：如果用户发了图片但你没加 `--collect-images`，管线会忽略用户的图片并自己用 AI 重新生成。这是**严重错误**，会让用户非常不满！

#### 用户要 AI 出多张图：加 `--image-count N`（默认 1）

赛道 YAML 默认只出 **1 张**封面。管线**不会**从 `--instruction` 里猜张数。用户口头要几张，**你（主模型）必须把数字写成参数**：

| 用户说 | 你加的参数 |
|---|---|
| 没提张数 /「发一篇」 | 不加（默认 1） |
| 「出 3 张」「要 5 张图」「封面+两张配图」 | `--image-count 3`（按说的数字，1–9） |
| 「多张」「一组图」但没说数字 | `--image-count 3` |
| 用户自己发了图 | 只加 `--collect-images`，不要 `--image-count` / `--image-briefs`。处理意见用 `--image-actions` + `--cover-text` |

```bash
# ✅ 没发图，口头要 3 张 AI 图
node scripts/xhs/pipeline.js --track tracks/xxx.yaml --mode review \
  --instruction "春季招生" --image-count 3

# ❌ 用户说了出 3 张，却只把原话塞进 --instruction、不加 --image-count
#    → 赛道仍是 1 张，用户会炸
```

禁止为了多出图去改 YAML。闲鱼是用户实拍，不要用这个参数。

#### 用户对画面有要求：加 `--image-briefs`（原样传给出图模型）

管线**不会**从 `--instruction` 里把「第一张画什么」传给出图模型。用户说了画面，**你必须写成 `--image-briefs`**：

| 用户说 | 你加的参数 |
|---|---|
| 没提画面 | 不加 |
| 「第一张教室上课，第二张家长沟通，第三张成果对比」 | `--image-count 3 --image-briefs "1:教室上课;2:家长沟通;3:成果对比"` |
| 「封面用暖色、不要真人脸」（没分张） | `--image-briefs "暖色、不要真人脸"` |
| 用户自己发了图 | 只加 `--collect-images`，处理意见用 `--image-actions` / `--cover-text`，**不要** `--image-briefs` |

```bash
# ✅ 3 张，且每张有作图要求
node scripts/xhs/pipeline.js --track tracks/xxx.yaml --mode review \
  --instruction "春季招生" \
  --image-count 3 \
  --image-briefs "1:教室上课;2:家长沟通;3:成果对比"

# ❌ 只把「第一张教室…」塞进 --instruction
#    → 出图模型看不到，会自己编画面
```

`--instruction` 只放内容主题；画面要求走 `--image-briefs`。不要改 YAML。

#### 用户发了实拍素材：加 `--image-actions` / `--cover-text`

有图时必须 `--collect-images`。**怎么处理每张图、封面写哪几个字，不能只塞进 `--instruction`**（解析器经常剥掉，叠字/出图模型收不到）。

| 用户说 | 你加的参数 |
|---|---|
| 发了图，没说怎么处理 | `--collect-images`（默认原图直发） |
| 「第一张做封面，其余原图」 | `--collect-images --image-actions "1:ai_cover;2:original"` 或 `"1:封面，其余原图"` |
| 「全部原图直发」 | `--collect-images --image-actions "原图直发"` |
| 「封面大字写成春季招生」 | `--cover-text "春季招生"`（实拍叠字和 AI 封面都用这句） |
| 「第一张叠字，大字写名额有限，后面原图」 | `--image-actions "1:ai_cover，其余原图" --cover-text "名额有限"` |

```bash
# ✅ 用户发了图 + 要改封面大字 + 其余原图
node scripts/xhs/pipeline.js --track tracks/xxx.yaml --mode review \
  --collect-images \
  --instruction "春季招生" \
  --image-actions "1:ai_cover，其余原图" \
  --cover-text "春季招生 名额有限"

# ❌ 只把「第一张做封面，大字写成…」写进 --instruction
#    → 管线猜不准，出图/叠字模型经常看不到
```

动作取值：`ai_cover`（封面叠字）/ `original`（原图直发）。中文「封面」「原图」也能认。

### 规则 5：审批中 skill 只提供能力，Agent 理解人话（禁止抢屏）

`--mode review` 跑着时，管线在 `pollForReply` 里等**结构化意图**，不猜长句。

| 入口 | 谁执行 |
|---|---|
| 卡片按钮（确认发布 / 重新写 / 取消） | 脚本（MQTT → `pending-approval.json`） |
| **发 / 取消 / 换图 / 重新写**（可带 @） | 脚本直接吃 |
| **改标题 / 记得标题为 / 图片上的大字是 / 换图：**（可带 @、可同条） | 脚本直接吃 |
| **@机器人** 但不是上面这些（查进度、看日志、闲聊） | **你**立刻查并回复 |
| 只发图片 | 脚本收集，随后「发」用新图 |

> ⏱ 设备时钟不可信：群聊文本/收图靠飞书 `messageId` + `create_time`；按钮和 `approve.js` 靠本机 `pending-approval.json`。

> ⚠️ **绝对不能再启动一条 `pipeline.js`。** 两个 Android 进程抢同一块屏幕会冲突。

#### @ 你时：能解析的改稿脚本会自己吃；你禁止复读「交给轮询」

**绝对禁止**对用户说「这是审批词」「交给底层轮询」「交给脚本处理」。那等于没干活。

- `@` + `发` / `重新写` / `改标题` / `记得标题为` / `图片上的大字` / `换图` → **脚本会执行**。你正确反应是 **`NO_REPLY`**（不要 `approve.js`，否则双消费）。
- `@` + 查进度 / 看日志 / 脚本没听懂的改法 → **你立刻查或调用** `approve.js --from-text "原文"` / `--action modify_title_and_image --title "..." --image-hint "封面大字改成..."`。
- `approve.js` 成功 → `NO_REPLY`；失败必须把 JSON 里的 `msg` 回给用户。

```bash
node scripts/approve.js --from-text "用户这条消息的原文"
node scripts/approve.js --action modify_title_and_image --title "新标题" --image-hint "图片上的大字改成：🏫……"
```

| 用户意图 | 你该怎么做 |
|---|---|
| @ 你改当前草稿（发/重写/改标题/大字）且口令脚本能认 | **`NO_REPLY`**，禁止解释，禁止再 `approve.js` |
| @ 你改草稿但说法很散，或 `approve.js` 失败 | 显式 `--action` / `--from-text`；失败要回话 |
| **查状态**：卡住了吗、跑完没、看进度、看日志 | **立刻查并回复**（`pgrep` / log 尾部）。禁止 `NO_REPLY` |
| **不碰屏**：改 YAML、解释报错、看配置 | 直接做 |
| **会抢屏**：再发一篇、养号、扫私信 | 说明屏幕正被占用；问：等结束 / 飞书「取消」后重来。未授权勿 kill |
| 闲聊或看不出 | 问一句要查进度还是改这篇；**禁止沉默** |

硬性要求：
1. 禁止输出「交给轮询 / 交给底层脚本 / 这是审批词」。改稿要么脚本已吃（你 `NO_REPLY`），要么你跑 `approve.js`。
2. 「任务久了没跑完」默认按**查状态**。
3. 只有管线已结束（成功 / 失败 / 超时 / 取消）后，才接受新的**抢屏发文**。

### 规则 6：管线报错时的应急处理

如果管线执行中报错退出（exit code 非 0），按以下流程处理：

1. **收集最后 50 行日志**，推送到飞书群告知用户
2. **不要自动重试**，除非用户明确要求"再跑一次"
3. 常见错误及处理：

| 错误关键字 | 含义 | 处理 |
|---|---|---|
| `FATAL ERROR` + `创作所需的权限` | 抖音权限弹窗（设备无摄像头） | 管线会自动关闭弹窗，无需干预 |
| `检测到已有管线进程` | 有另一个管线在运行 | 等待旧管线完成，或让用户在群里发"取消"后等 15 秒再试 |
| `登录` / `login` | App 需要重新登录 | 截图推飞书，提醒用户手动登录 |
| `图片生成失败` | AI 图片服务不可用 | 建议用户通过 `--images` 或 `--collect-images` 提供自己的图片 |
| `飞书预览发送失败` | 飞书配置问题 | 检查 `~/.openclaw/openclaw.json` 的飞书配置 |
| `ADB 连接失败` / `设备未连接` | ADB 无线调试断开 | 运行 `node scripts/adb-helper.js` 诊断；品牌 Pad 需检查无线调试端口是否变化 |
| `所有输入方案失败` | 无法输入中文 | 运行 `node scripts/test-input.js` 诊断；确认已安装 Termux:API |
| `shell 命令失败(重试3次)` | ADB 命令执行失败（重试后仍失败） | 检查设备是否在线、ADB 连接是否正常 |

### 规则 7：必须用后台模式执行管线（防系统阻塞！）

管线命令（pipeline.js）通常需要 **5-30 分钟**才能完成（review 模式需要等老板审批，可能耗时 2 小时）。
**你必须用后台模式执行**，否则你会被阻塞，整个 OpenClaw Agent 无法响应用户任何消息——这是最严重的系统级故障。

#### 正确调用方式（OpenClaw exec 标准格式）

```yaml
# ✅ 正确：后台执行，5 秒后 yield 控制权回到 Agent
exec: node /home/openclaw/workspace/skills/android-worker-node/scripts/xhs/pipeline.js --track tracks/xxx.yaml --mode review
background: true
yieldMs: 5000
```

```yaml
# ✅ 正确：闲鱼断点续跑（也必须后台）
exec: node /home/openclaw/workspace/skills/android-worker-node/scripts/xianyu/pipeline.js --resume latest
background: true
yieldMs: 5000
```

#### 后台命令状态轮询 SOP

命令进入后台后返回 `sessionId`。你必须按以下流程管理：

```
1. 命令提交 → 拿到 sessionId
2. 立即回复用户："已开始执行，预计 X 分钟完成"
3. 后台自行用 process poll 跟踪；用户没 @ 你时不必刷屏汇报
4. 状态 = done + exitCode=0 → 告知用户成功
5. 状态 = done + exitCode≠0 → 收集最后 50 行日志，告知用户失败原因
6. 等待期间用户 @ 你「查一下 / 卡住了吗 / 看进度」→ 立刻 poll + 读日志回复现状（这是常态，不是打扰）
7. 等待期间用户提出不碰屏的问题 → 正常回答；提出抢屏新任务 → 先报当前占用再协商，勿装死
```

#### ⛔ 常见反模式（绝对禁止！）

| 反模式 | 后果 | 正确做法 |
|---|---|---|
| 同步执行管线（不加 `background: true`） | Agent 卡死 5-120 分钟，用户发消息无回应 | 必须加 `background: true` |
| 管线超时后再次同步等待 | 两层阻塞叠加，系统彻底卡死 | 用 `process poll` 异步检查 |
| 管线失败后立即自动重试 | 同一个 Bug 死循环，浪费资源 | 等用户指令再决定 |
| 同时启动多个管线 | UI 操作冲突，两个进程抢屏幕 | 严格串行（见规则 9） |

> ⚠️ **最严重的故障**：Agent 同步等待一个 review 模式的管线。review 需要老板飞书回复，可能等 2 小时。这 2 小时内 Agent 完全无响应，飞书群所有消息石沉大海，老板以为系统崩了。

### 规则 8：失败绝不自动重试

管线执行失败后：
1. **收集最后 50 行日志**，发给用户
2. **向用户报告失败原因**，等待用户指令
3. **绝不自己决定重试** — 除非用户明确说"再跑一次"

> ⚠️ **自动重试会导致灾难性循环！** 同一个错误重试 100 次还是同一个错误，只会浪费时间、消耗资源、阻塞 Agent。

### 规则 9：设备操作严格互斥（核心安全规则！）

同一台安卓设备的**物理屏幕只有一个**。任何发布管线都在操控这块屏幕上的 UI。
**两个管线同时操控同一块屏幕 = 灾难性冲突（按钮被误点、文案被串写、图片被换掉）。**

#### 互斥状态机

```
Agent 维护一个隐式状态变量：device_busy = true/false

  device_busy = false  →  可以启动新管线
  device_busy = true   →  必须等待，绝不启动新管线

以下操作会使 device_busy 变为 true：
  - 任何 pipeline.js 命令（xhs/douyin/xianyu 所有平台）
  - 断点续跑 --resume
  - 养号 nurture.js
  - App 内私信扫描 inbox-scraper.js（xhs/douyin/xianyu，会点开消息页）
  - 自有作品曝光 creator-analytics-scraper.js（xhs/douyin，创作者中心；禁止 works-scraper）
  - 半自动私信 dm-reply.js / 评论回复 comment-reply.js / 截流 intercept-comment.js / 竞品 research-scraper.js（会点屏）

以下事件会使 device_busy 恢复为 false：
  - 管线 sessionId 状态变为 done
  - inbox-scraper 命令退出（exitCode 任意）
  - 用户在飞书发"取消"+ 等待 15 秒
  - 管线崩溃退出（exitCode ≠ 0）

以下操作不受互斥限制（不操控屏幕）：
  - node scripts/adb-helper.js（设备诊断，只读）
  - 通知监听 notification-listener.js（只读 logcat，不碰 UI；只做门铃）
  - node scripts/track/generate.js（写入 skill `tracks/` YAML 并尝试云端入库，不碰屏幕）
  - node scripts/track/evolve.js（分析日志；飞书确认后可写回 YAML，不碰设备屏幕）
```

> ⚠️ **inbox-scraper / creator-analytics-scraper / dm-reply / comment-reply / intercept-comment / research-scraper 与 pipeline 互斥**：脚本内已检测或占用管线锁，管线忙时不要并行。Agent 也不要在管线运行中主动发起扫描或回复。不要跑 `works-scraper`（主页网格读不到有效数据，已停用）。

### 自有作品曝光（仅创作者中心）

走创作者数据中心（状态机识页）。主页「我」网格读不到有效标题/播放，**禁止**当数据源或兜底。

- 抖音：我 → 创作者中心 → 数据分析/更多 → 作品分析
- 小红书：我 → 菜单 → 创作者中心 → 最新笔记「更多」→ 作品分析

```bash
node scripts/xhs/creator-analytics-scraper.js
node scripts/douyin/creator-analytics-scraper.js
node scripts/xhs/creator-analytics-scraper.js --scrolls 2 --dry-run
```

写入 `memory/works-metrics/`（`source: creator_center`）。晚报 / 运营总监 / 营销总监 / evolve **只读创作者中心**；没有快照就写暂无。经 MQTT `openclaw/{SN}/works_metrics` 上报云端。管线忙时自动跳过。

#### 多任务排队策略

当用户要求"小红书和抖音都发一篇"或"先发闲鱼再发抖音"时：

```
1. 启动第一个管线（后台），拿到 sessionId_A
2. 回复用户："已开始小红书发布，完成后自动发抖音"
3. 轮询 sessionId_A 直到完成
4. sessionId_A 完成后，等待 10 秒（让 App 状态归位）
5. 启动第二个管线（后台），拿到 sessionId_B
6. 轮询 sessionId_B
7. 两个都完成后汇总结果给用户
```

> ⚠️ **绝不并行！绝不并行！绝不并行！** 即使用户说"同时发"，你也必须串行执行。
> 回复："好的，我先发小红书，完成后再发抖音。两个平台不能同时操作手机屏幕哈。"

#### 进程锁保护（管线内置，但 Agent 也必须遵守）

管线内置了进程锁（`acquireProcessLock`），如果检测到已有管线在运行，新管线会自动拒绝启动并输出 `检测到已有管线进程`。
但 **Agent 不能依赖进程锁做互斥**——因为被拒绝启动本身就是一次无意义的资源消耗。Agent 应该主动维护状态，避免触发进程锁。

### 规则 10：管线崩溃恢复预案

当管线异常退出（非正常完成）时，设备可能处于不确定状态：App 停留在某个中间页面、键盘弹出未收回、弹窗未关闭等。

**恢复 SOP（在启动下一个管线之前执行）**：

```bash
# 1. 按 Home 键回到安卓主屏，清理残留状态
adb shell input keyevent 3
sleep 2

# 2. 强制关闭可能残留的 App（根据刚才跑的是哪个平台）
adb shell am force-stop com.taobao.idlefish    # 闲鱼
adb shell am force-stop com.ss.android.ugc.aweme # 抖音
adb shell am force-stop com.xingin.xhs          # 小红书
sleep 2

# 3. 现在可以安全启动下一个管线
```

> agent 不需要每次都跑这个——只有**上一个管线异常退出**后才需要清理。正常完成的管线会自行收尾。

---

## 核心架构：零人工自动校准 (Zero-touch Auto Calibration)

为了能在完全未适配过的几十种不同尺寸/分辨率 Android/Pad 设备上即插即用，管线针对如“发闲置”、“+添加优质图片”等易遭遇底层 Accessibility 拦截变瞎的核心控制区，采用了**自动视觉校准与本地缓存**机制：

- **第一阶段（开荒）**：如果你在一台新设备上首次运行，Agent 遇到不认识的覆盖层，不会放弃或盲猜，而是求助于 OpenClaw 中配置的低延迟“傻模型”（通过 `qwen-vision` 模块）进行一次精准的多模态视觉识别，找出该按钮所在的百分比坐标 `(pctX, pctY)`，将其缓存在本机的 `~/.openclaw/cache/vision_layout.json` 文件内。由于需要走大模型图文传输，**第一单通常比较慢**（会在该环节稍有几秒卡顿）。
- **第二阶段（复用）**：一旦这台机器上开荒完成，从第二单开始的千层百次发布，代码会直通车调取本地分辨率命中的高速缓存百分比计算物理坐标。在保障跨硬件鲁棒性的前提下，实现**毫无延迟的物理级瞬间盲击**。

> **💡 配置建议**：不需要你亲自调校任何 XML `adb.tap()` 的机型坐标！但强烈推荐在 `openclaw.json` 的 `models.providers.bailian` 或者兼容环境里，配置基于阿里百炼等较便宜/迅速的 `qwen3.5-plus` 大模型作为“视觉探索的眼睛”，这远比耗费极贵的 Gemini 划算。

---

## 核心架构：权益鉴权体系 (Skill Entitlement)

为了支持 OpenClaw 的商业化售卖，管线内置了**在线权益鉴权与离线降级策略**。

- **模块化控制**：所有自动化能力被划分为不同的 Module（例如 `xhs_post`, `douyin_nurture`, `xianyu_login` 等）。设备在执行这些功能前，会通过 `requireModule()` 进行鉴权。
- **在线拉取与本地缓存**：每次管线启动时，会请求云端 `GET /skill/entitlement/:sn` 接口获取当前设备购买的套餐和功能权限，并写入本地 `~/.openclaw/entitlement_cache.json`。
- **降级保护**：当设备处于弱网或断网状态（接口请求失败）时，如果本地有 24 小时内的缓存，则使用缓存判定；如果连缓存都没有（比如首次部署且无网），系统会采取**宽容降级（Fail-open）**策略默认放行，确保即便网络短暂波动也不会导致客户买的设备变"砖头"。
- **未授权拦截**：如果鉴权明确被拒绝（套餐过期或未购买该模块），管线会在控制台报错，并通过飞书发送一条带有"开通服务"链接的友好提示卡片，引导客户续费或升级。

---

## 新设备部署清单

支持多种硬件平台部署：
- **开发板**：Radxa ROCK 4D、泰山派（RK3576/RK3588）— 自带 root，ADB 端口固定 5555
- **品牌 Pad**：三星 Tab S9+ 等 — 无 root，ADB 无线调试端口**每次重启会变**（系统自动动态发现）
- **白牌平板（推荐出货机型）**：酷比魔方掌玩 mini2 4G（MT6789）— 可 root（mtkclient 解锁 + Magisk），ADB 端口固定 5555

### 前置条件

| 步骤 | 命令/操作 | 说明 |
|---|---|---|
| 1. 安装 Termux | 从 F-Droid 下载安装 | 不要用 Play Store 版（签名不同会导致插件冲突） |
| 2. 安装 Node.js | `pkg install nodejs-lts` | 需要 Node.js 16+ |
| 3. 安装 ADB | `pkg install android-tools` | Termux 内的 ADB 客户端 |
| 4. 开启无线调试 | 设置 → 开发者选项 → 无线调试 → 配对 | 详见 `bash scripts/setup-adb.sh` |
| 5. ADB 连接本机 | `adb pair localhost:<配对端口>` + `adb connect localhost:<连接端口>` | 配对成功后端口保存到 `~/.adb_port` |
| 6. ADB 持久化 | 按设备类型配置（见下方） | **关键！不配置的话重启后 ADB 失效** |

### ⚠️ ADB 重启持久化（必配！）

Android 重启后会关闭无线调试、清除 `adb tcpip` 设置。**不做持久化配置的设备，每次重启都需要手动重连 ADB。**

#### Radxa / 开发板 / 白牌平板（Root 设备）— 一劳永逸

适用于：Radxa、泰山派、酷比魔方掌玩 mini2 等已 root 设备。

在 Magisk 的 `service.d` 下创建开机脚本，固化 ADB TCP 端口：

```bash
# 创建脚本
cat > /data/adb/service.d/enable_adb_tcp.sh << 'EOF'
#!/system/bin/sh
sleep 10
setprop persist.adb.tcp.port 5555
setprop service.adb.tcp.port 5555
stop adbd
start adbd
EOF

# 赋权
chmod +x /data/adb/service.d/enable_adb_tcp.sh
```

也可在 `build.prop` 中直接写入 `persist.adb.tcp.port=5555`（适用于自定义 ROM）。

配置后 ADB 固定在 5555 端口，重启无影响，**客户交付首选此方案**。

#### 白牌平板 Root 隐藏（必配！）

> ⚠️ **白牌平板 root 后必须配置隐藏！** 闲鱼/支付宝会检测 bootloader 解锁状态，检测到后会**故意压暗前置摄像头画面**，导致活体认证失败。

**方案 B（推荐 ✅）：KernelSU Next**

KernelSU 运行在内核层，天然不会在用户空间留下 root 痕迹。实测闲鱼正常登录、活体认证通过。

| 模块 | 作用 |
|---|---|
| **TrickyStore** | 伪造 bootloader 锁定状态 |
| **Play Integrity Fix** | 伪造 Play Integrity 设备认证（KOWX712 KSU 适配版） |

KernelSU Manager → 超级用户 → 对闲鱼/支付宝/淘宝/抖音/小红书/微信设置「拒绝」，允许 Termux 和 Shell。

**方案 A：Magisk + Shamiko**

| 模块 | 作用 |
|---|---|
| **Shamiko** | 隐藏 root（su、Magisk 痕迹） |
| **Play Integrity Fix** | 伪造 Play Integrity 设备认证 |
| **TrickyStore** | 伪造 Keystore/TEE（bootloader 锁定状态） |

Magisk 设置：Zygisk 开启、遵守排除列表关闭（Shamiko 接管）、DenyList 勾选目标 App。

> 完整操作步骤详见 `白牌平板出货配置文档`。

#### 三星 S9+（Non-Root 设备）— adb-auto-enable APK

> ⚠️ **三星有 Knox 硬件熔丝，root 会永久触发 Knox 标记，无法隐藏。品牌 Pad 不要 Root！**

安装开源 APK [adb-auto-enable](https://github.com/mouldybread/adb-auto-enable)（MIT 协议），实现开机自动恢复 ADB：

**工作原理：**
```
开机 → BootReceiver 拉起前台 Service
     → 等待 WiFi 就绪（最长 2 分钟）
     → settings put global adb_wifi_enabled 1
     → mDNS 发现动态端口
     → 自实现 ADB 协议连接 localhost:<动态端口>
     → 发送 tcpip:5555 切换到固定端口
     → 完成
```

**部署步骤：**

| 步骤 | 操作 | 说明 |
|---|---|---|
| 1. 安装 APK | 从 GitHub Releases 下载安装 | |
| 2. 首次配对 | 浏览器访问 `http://设备IP:9093` → 输入配对码 | 设置 → 开发者选项 → 无线调试 → 配对 |
| 3. 自动授权 | App 自动执行 `pm grant` 获得 WRITE_SECURE_SETTINGS | 如失败需手动 USB 授权一次 |
| 4. 验证 | 重启设备，等 90 秒，检查 `adb devices` | 应看到 `emulator-5554` 和/或 `localhost:5555` |

**实测结果：** 重启后 `emulator-5554`（端口 5554）可供 Termux 使用，`localhost:5555` 被 App 占用。adb-helper.js 会自动识别可用设备。

**限制：**
- ⚠️ **必须连接 WiFi**：无线调试依赖 WiFi 连接。如果用 SIM 卡实现一机一IP，需要额外搭一个无上网的本地 WiFi AP（设备连 WiFi 保持 ADB，流量走移动数据）
- ⚠️ **不适合直接交付客户**：WiFi + SIM 双连接配置复杂。**客户交付用白牌 Root 方案或 Radxa，自营设备用此方案**

#### 辅助措施（所有设备通用）

| 措施 | 操作 | 目的 |
|---|---|---|
| 禁用 OTA 自动更新 | 开发者选项 → 关闭"自动系统更新" | 防止系统更新触发重启 |
| 保持充电 | 设备常插电源 | 防止电量耗尽关机 |
| 关闭自动重启 | 三星：设置 → 电池 → 关闭"自动重启" | 减少不必要的重启 |

### ⚠️ 中文输入配置（关键！不装就发不出帖）

**新设备必须至少安装一个输入方案**，否则管线会在文案输入步骤直接报错退出。

#### 方案 A：Termux:API（推荐✅，不需要 root，所有设备通用）

```bash
# 第 1 步：在 Termux 内安装命令行工具
pkg install termux-api

# 第 2 步（必须！）：安装 Termux:API 的 Android 应用（APK）
# 从 F-Droid 下载安装：https://f-droid.org/packages/com.termux.api/
# ⚠️ 两步缺一不可！pkg 只装了命令行，没有 APK 的话 termux-clipboard-set 会报错

# 验证：
echo "测试中文" | termux-clipboard-set && echo "✅ 成功"
```

**原理**：Termux 是前台 App，通过 Termux:API 设置剪贴板不受 Android 14 限制。管线自动检测到 `termux-clipboard-set` 可用后会优先使用此方案。


### 输入方案

管线使用 `termux-clipboard-set` 作为唯一文本输入方案：

```
termux-clipboard-set（不需要 root，Android 14 兼容）
```

> ⚠️ **已弃用的旧方案**：ADBKeyboard、ClipHelper (clip.dex) 和 content-provider 已全部移除。
> 如果你在旧文档或日志中看到这些方案名称，请忽略。

首次运行时自动检测 termux-clipboard-set 可用性。**如果不可用，管线会在启动阶段直接报错退出**（不再静默跳过）。

```bash
# 诊断工具：测试所有方案，输出哪个可用
node scripts/test-input.js

# 完整设备诊断（连接 + 权限 + 输入 + 截图）
node scripts/adb-helper.js
```

### 其他初始化

| 步骤 | 命令 | 说明 |
|---|---|---|
| 克隆项目 | `git clone <仓库地址> ~/openclaw/workspace/skills/android-worker-node` | 在 Termux 内 |
| 安装依赖 | `cd ~/openclaw/workspace/skills/android-worker-node && npm install` | |
| 配置文件 | 编辑 `~/.openclaw/openclaw.json` | API keys、飞书通道等 |
| 上传赛道 | 将 `.yaml` 赛道文件放入 `tracks/` 目录 | |
| 启动通知监听（门铃） | 见「线索捕获」章节 | 推送只做门铃，真线索靠 inbox |
| 注册线索定时任务 | 见「定时任务自动配置」 | 三平台 inbox cron + 监听自愈 |
| 验证连接 | `node scripts/adb-helper.js` | **完整设备诊断**：连接、权限、输入方案、截图 |
| 测试输入 | `node scripts/test-input.js` | 中文输入诊断 |

---

## 运营模式说明

系统支持 5 种运营模式，适用于不同场景：

| 模式 | 说明 | 适用场景 |
|---|---|---|
| `review` | 审批模式：AI 生成 → 飞书推预览 → 老板确认后发布 | **推荐日常使用** |
| `full` | 全自动：AI 生成 → 直接发布 | 定时任务、夜间调度 |
| `draft` | 只生成内容，不发布 | 内容储备、提前审稿 |
| `research` | 只做竞品搜索 | 市场调研 |
| `warmup` | 养号（刷同赛道视频/笔记） | **仅抖音新号冷启动**，日常不需要 |

### review 模式（审批发布）工作流

```
AI 生成草稿 → 飞书推送预览卡片（标题+正文+封面图）

老板可以在飞书群中：
  点卡片按钮「确认发布 / 重新写 / 取消」
  未 @ 短口令："发" / "换图" / "重新写" / "取消"
  未 @ 结构化："改标题：xxx"（可同条再加「换图：封面大字改成yyy」）
  @ 设备机器人：由 Agent 调用 `scripts/approve.js`（复杂改稿、组合指令）
  发图片后再「发」→ 用你的图替换封面
  什么都不回（超时 2 小时）→ 自动放弃，草稿保留

📸 发图片替换：审批等待期间，如果您在群里发了图片，系统会自动下载。
   后续只要回复"发"，就会用您的图片替代 AI 图片进行发布。
```

---

## 所有可用命令（完整列表）

### 小红书 — 审批发布（推荐）

```bash
node scripts/xhs/pipeline.js --track tracks/<赛道名>.yaml --mode review
```

AI 生成内容 → 飞书推预览 → 等老板在飞书群确认 → 自动发布。**推荐日常使用。**

> 识页：编辑页「添加标题 / 添加正文 / 发布笔记」优先于推荐话题里的「拍照」；找不到「从相册选择」禁止乱点第一个元素。

### 小红书 — 审批发布 + AI 多图（用户口头要 N 张）

```bash
node scripts/xhs/pipeline.js \
  --track tracks/<赛道名>.yaml \
  --mode review \
  --instruction "用户的文字创意要求" \
  --image-count 3 \
  --image-briefs "1:封面场景;2:配图场景;3:配图场景"
```

> 不提张数就不要加 `--image-count`（默认 1）。有画面要求必须加 `--image-briefs`。不要改 YAML。

### 小红书 — 审批发布 + 用户图片 + 创意指令

```bash
node scripts/xhs/pipeline.js \
  --track tracks/<赛道名>.yaml \
  --mode review \
  --collect-images \
  --instruction "用户的文字创意要求" \
  --image-actions "1:ai_cover;2:original" \
  --cover-text "封面大字原文"
```

### 小红书 — 全自动发布

```bash
node scripts/xhs/pipeline.js --track tracks/<赛道名>.yaml --mode full
```

### 小红书 — 只生成草稿（不发布）

```bash
node scripts/xhs/pipeline.js --track tracks/<赛道名>.yaml --mode draft
```

### 小红书 — 只做竞品研究（TopN 深挖）

```bash
# 推荐：独立脚本（关键词或赛道）
node scripts/xhs/research-scraper.js --keyword "少儿编程" --top 5
node scripts/xhs/research-scraper.js --track tracks/<赛道名>.yaml --top 5

# 管线模式（读赛道 research.competitor_keywords，深挖 Top5）
node scripts/xhs/pipeline.js --track tracks/<赛道名>.yaml --mode research
```

结果写入 `memory/research/` + `wiki/local/research-xhs-*.md`，并推飞书洞察。权益：`research`。

### 小红书 — 养号（刷信息流，仅新号推荐）

```bash
# ⚠️ 仅新号冷启动时使用，已运营的号不需要
node scripts/xhs/nurture.js --duration 30
```

### 抖音 — 审批发布（推荐）

```bash
node scripts/douyin/pipeline.js --track tracks/<赛道名>.yaml --mode review
```

> 识页：编辑页「添加作品描述 / 添加标题 / 发作品」优先于推荐话题里的「拍照/拍摄」；拍摄页必须有闪光灯/翻转，不能靠「选择音乐」。

### 抖音 — 审批发布 + AI 多图（用户口头要 N 张）

```bash
node scripts/douyin/pipeline.js \
  --track tracks/<赛道名>.yaml \
  --mode review \
  --instruction "用户的文字创意要求" \
  --image-count 3 \
  --image-briefs "1:封面场景;2:配图场景;3:配图场景"
```

### 抖音 — 审批发布 + 用户图片 + 创意指令

```bash
node scripts/douyin/pipeline.js \
  --track tracks/<赛道名>.yaml \
  --mode review \
  --collect-images \
  --instruction "用户的文字创意要求" \
  --image-actions "1:ai_cover;2:original" \
  --cover-text "封面大字原文"
```

### 抖音 — 全自动发布

```bash
node scripts/douyin/pipeline.js --track tracks/<赛道名>.yaml --mode full
```

### 抖音 — 只生成草稿

```bash
node scripts/douyin/pipeline.js --track tracks/<赛道名>.yaml --mode draft
```

### 抖音 — 只做竞品研究（TopN 深挖）

```bash
node scripts/douyin/research-scraper.js --keyword "少儿编程" --top 5
node scripts/douyin/pipeline.js --track tracks/<赛道名>.yaml --mode research
```

### 抖音 — 养号（仅新号冷启动推荐）

```bash
# ⚠️ 仅新号冷启动时使用，已运营的号日常发布不需要先养号
# warmup 模式：刷同赛道视频 15-30 分钟
node scripts/douyin/pipeline.js --track tracks/<赛道名>.yaml --mode warmup

# 独立养号脚本
node scripts/douyin/nurture.js --duration 30
```

### 闲鱼 — 审批发布（推荐）

```bash
node scripts/xianyu/pipeline.js --track tracks/<赛道名>.yaml --mode review
```

AI 生成闲鱼商品文案 → 飞书推预览 → 等老板确认 → 自动发布到闲鱼 App。**推荐日常使用。**

### 闲鱼 — 审批发布 + 用户图片 + 创意指令

```bash
node scripts/xianyu/pipeline.js \
  --track tracks/<赛道名>.yaml \
  --mode review \
  --collect-images \
  --instruction "用户的文字要求"
```

### 闲鱼 — 全自动发布

```bash
node scripts/xianyu/pipeline.js --track tracks/<赛道名>.yaml --mode full
```

### 闲鱼 — 快速发布（用户直接提供标题+价格+图片）

```bash
# 最简单的用法：用户说"帮我挂个闲鱼"时
node scripts/xianyu/pipeline.js \
  --track tracks/<赛道名>.yaml \
  --mode quick-publish \
  --title "商品标题" \
  --price 99 \
  --collect-images

# 带描述
node scripts/xianyu/pipeline.js \
  --track tracks/<赛道名>.yaml \
  --mode quick-publish \
  --title "商品标题" \
  --price 99 \
  --description "详细描述" \
  --collect-images
```

### 闲鱼 — 只生成草稿

```bash
node scripts/xianyu/pipeline.js --track tracks/<赛道名>.yaml --mode draft
```

### 闲鱼 — 只做竞品研究

```bash
node scripts/xianyu/pipeline.js --track tracks/<赛道名>.yaml --mode research
```

### 闲鱼 — 养号（浏览推荐流+搜索同品类）

```bash
# ⚠️ 仅新号冷启动时使用
node scripts/xianyu/nurture.js --track tracks/<赛道名>.yaml --count 10
```

### 闲鱼 — 登录/检测

> ⚠️ 闲鱼/淘宝登录涉及**活体验证（人脸识别）**，必须由用户在设备上手动完成。
> 首次登录后 session 可持久数月，无需频繁重复。

```bash
# 登录（打开闲鱼→检测状态→推飞书提示→等待手动操作）
node scripts/xianyu/pipeline.js --mode login

# 检查登录状态
node scripts/xianyu/pipeline.js --mode check
```

### 断点续跑（三平台通用）— 发布卡住后恢复

> 当 App 改版或 bug 导致发布步骤失败时，修复代码后用 `--resume` 直接恢复发布，
> **跳过内容生成和图片生成**，不浪费 AI token 和等待时间。

```bash
# 小红书 — 自动找最新未发布草稿
node scripts/xhs/pipeline.js --resume latest

# 抖音 — 指定草稿文件
node scripts/douyin/pipeline.js --resume drafts/20260416-douyin-教培.json

# 闲鱼 — 自动找最新
node scripts/xianyu/pipeline.js --resume latest
```

> 草稿文件保存在 `drafts/` 目录，包含完整的标题、正文、标签和图片路径。
> 发布成功后草稿自动重命名为 `.published.json`，不会被重复使用。

### 线索捕获（App 内私信为主 + 推送门铃）— Agent 自动配置

> ⚠️ **架构铁律（写进每台设备的运行方式）**
>
> | 通道 | 角色 | 说明 |
> |---|---|---|
> | **App 消息页扫描** `*/inbox-scraper.js` | **真线索主源** | 进入小红书/抖音/闲鱼「消息」页读会话列表 |
> | **系统推送监听** `notification-listener.js` | **门铃** | 识别私信/赞/评/关/垃圾；私信入 `verify_queue`；**不当唯一线索源** |
>
> - 小红书推送常有「xxx私信你」→ 门铃有用，仍须 inbox 核实  
> - **抖音陌生人私信经常没有系统推送** → 必须靠 inbox（含「陌生人消息」盒），cron 更勤  
> - 闲鱼买家消息多会推，但物流/擦亮/官方通知要滤掉  
> - 赞 / 收藏 / 关注 / 运营推荐 → **一律丢弃，不当线索**  
>
> **禁止**再把「推送 LLM 评估」当主路径。信号表在 `scripts/notification-patterns.js`。

#### 一键指令（用户飞书说这些话时，Agent 必须自动做完）

| 用户说法 | Agent 动作 |
|---|---|
| 「初始化设备」「部署完成」「配置定时任务」「配置线索捕获」 | ① 启动 notification-listener ② **禁止写 `~/.openclaw/cron/jobs.json`**（2026.6+ 任务在 Gateway/SQLite，写文件无效）。用 `openclaw cron add --command … --no-deliver`，或让老板在管理端「下发标准包」③ 用 `openclaw cron list --json` 核对 12 条均为 `kind:command`
| 「开始通知监听」「启动门铃」 | 只做监听进程启动 + 健康检查 cron |
| 「扫描私信」「抓线索」「看消息」 | 视平台跑对应 inbox；未指定则 **三平台各扫一次**（串行，互斥） |
| 「扫小红书私信」 | `node scripts/xhs/inbox-scraper.js` |
| 「扫抖音私信 / 陌生人消息」 | `node scripts/douyin/inbox-scraper.js` |
| 「扫闲鱼消息」 | `node scripts/xianyu/inbox-scraper.js` |
| 「抓作品数据 / 看阅读量 / 看播放量」 | `node scripts/xhs/creator-analytics-scraper.js` 与 `node scripts/douyin/creator-analytics-scraper.js` |

#### App 内私信扫描（真线索）

```bash
cd ~/openclaw/workspace/skills/android-worker-node

# 小红书
node scripts/xhs/inbox-scraper.js
# 抖音（会尝试进入「陌生人消息」盒）
node scripts/douyin/inbox-scraper.js
# 闲鱼
node scripts/xianyu/inbox-scraper.js

# 只解析不上报 / 不推飞书
node scripts/xhs/inbox-scraper.js --dry-run
node scripts/douyin/inbox-scraper.js --no-feishu
```

**行为要点**：
- 会操控屏幕 → **与 pipeline 互斥**；检测到管线锁则跳过并打印 `pipeline_busy`
- 消费 `memory/verify_queue.jsonl` 门铃队列，命中发送人则提权
- 上报 `lead_event`（`source=app_inbox` / `app_inbox+push` / `app_inbox_stranger`）
- 疑似线索推飞书；系统助手/物流/活动会话自动过滤

**数据文件**：
- `memory/xhs_inbox_seen.json` / `douyin_inbox_seen.json` / `xianyu_inbox_seen.json` — 去重
- `memory/xhs_inbox_log.md` 等 — 扫描日志
- `memory/verify_queue.jsonl` — 推送门铃待核实队列
- `memory/attribution_index.jsonl` — 线索归因索引

#### 推送门铃（notification-listener）

**原理**：logcat 事件流 → dumpsys 取文案 → `classifyPush` 按平台识别行为 → 私信入队；仅「可靠平台 + 私信 + 意向词」才发飞书门铃。

**不调逐条 LLM**（省 token、减误报）。赞/关/运营直接丢。

**启动（必须 `setsid`）**：

```bash
PID_FILE="$HOME/.notification-listener.pid"
if [ -f "$PID_FILE" ] && kill -0 $(cat "$PID_FILE") 2>/dev/null; then
  echo "通知监听已在运行 (PID: $(cat $PID_FILE))"
else
  cd ~/openclaw/workspace/skills/android-worker-node
  mkdir -p ~/openclaw/workspace/logs
  setsid node scripts/notification-listener.js >> ~/openclaw/workspace/logs/notification-listener.log 2>&1 &
  disown
  echo "通知监听已启动 (PID: $!)"
fi
```

**停止**：
```bash
PID_FILE="$HOME/.notification-listener.pid"
[ -f "$PID_FILE" ] && kill $(cat "$PID_FILE") && rm -f "$PID_FILE" && echo "已停止"
```

**查看状态**：
```bash
ps aux | grep notification-listener | grep -v grep
tail -30 ~/openclaw/workspace/logs/notification-listener.log
tail -20 ~/openclaw/workspace/memory/notification_log.md
cat ~/openclaw/workspace/memory/notification_report_$(date +%Y-%m-%d).json 2>/dev/null
```

#### 容错（监听进程）

| 层 | 机制 |
|---|---|
| 保活 | 启动时 standby-bucket / deviceidle / freezer |
| 自愈 | cron 每 5 分钟健康检查拉起 |
| 补漏 | 启动时扫系统通知栏；更重要的是 **inbox cron 定时扫消息页** |

前置：`adb devices` 有设备（Termux 无系统通知权限，必须走 ADB）。

#### 每日晚报与线索

agent 在每天 22:00 跑 `daily-report.js` 时：
- **真线索数字来自** `memory/events/lead_*.json`（`lead-stats.js`），以 App 内 inbox 为准
- 推送门铃只作辅线；**不写「0 线索」**若仅无推送——应写「消息页定时扫描 + 推送门铃待命」
- 运营总监 / 营销总监 / MQTT `todayStats.leads` 同一数据源

#### 半自动私信回复（小红书 / 抖音 / 闲鱼）

> 流程：**挑线索 → LLM 草稿 → 飞书确认 → 点屏发送**。禁止全自动乱发。  
> 权益：`auto_reply_dm`（管理后台 Skill 套餐须勾选；无权益则脚本退出）

```bash
cd ~/openclaw/workspace/skills/android-worker-node
# 小红书
node scripts/xhs/dm-reply.js
node scripts/xhs/dm-reply.js --lead-id lead_xhs_xxx
# 抖音（会进陌生人消息盒）
node scripts/douyin/dm-reply.js
node scripts/douyin/dm-reply.js --lead-id lead_douyin_xxx
node scripts/douyin/dm-reply.js --dry-run
# 闲鱼
node scripts/xianyu/dm-reply.js
node scripts/xianyu/dm-reply.js --lead-id lead_xianyu_xxx
node scripts/xianyu/dm-reply.js --dry-run
```

**飞书确认词**：`发` = 点屏发送；`重写` = 重新生成；`取消` = 放弃。  
**互斥**：占用 `openclaw-pipeline.lock`，与发布管线不能并行。  
**Agent**：
- 「回复私信 / 半自动回复 / 跟进线索」→ 先问清平台；未指定则**小红书优先**，或按 xhs → douyin → xianyu 各一条
- 「回复抖音私信 / 跟进抖音线索」→ `node scripts/douyin/dm-reply.js`
- 「回复闲鱼私信 / 跟进闲鱼买家」→ `node scripts/xianyu/dm-reply.js`
- **必须 `background: true`**（可能等飞书确认约 1 小时）

#### 半自动评论回复（自己帖/作品下 · 小红书 / 抖音）

> 流程同私信：**挑评论线索 → 草稿 → 飞书确认 → 进评论/@/互动消息点屏回复**。  
> 权益：`auto_reply_comment`  
> 线索来源：推送门铃把评论记为 `source=comment` 的 lead 事件。

```bash
node scripts/xhs/comment-reply.js
node scripts/xhs/comment-reply.js --lead-id …
node scripts/douyin/comment-reply.js
node scripts/douyin/comment-reply.js --dry-run
```

**Agent**：「回复评论 / 跟进评论」→ 问清平台；未指定先小红书再抖音（`background: true`）

#### 半自动截流评论（他人笔记/作品下留钩 · 小红书 / 抖音）

> 高风险能力：搜索关键词 → 打开热门内容 → **立刻打开评论框锁住当前页** → 草稿 → **飞书确认（按钮 + 自然语言）** → 发送。  
> 默认每日上限 3 条（分平台计数）。权益：`intercept_comment`（与 `auto_reply_comment` 分开售卖）。
> 飞书卡片可点「确认发送 / 重新写 / 取消」，也可回复「发」「重写」「取消」或直接发改写正文。  
> 审批等待期间**不退出、不重搜**（重搜无法保证同一条）；通过后会先回飞书「开始操作手机…」。

```bash
node scripts/xhs/intercept-comment.js --keyword "装修避坑"
node scripts/douyin/intercept-comment.js --keyword "少儿编程"
node scripts/xhs/intercept-comment.js --keyword "xx" --limit 3 --dry-run
```

**Agent**：「截流 / 去热帖留言」→ 必须先确认平台与关键词；`background: true`。禁止全自动连发。

#### Skill 套餐 moduleId 对照（管理后台 `/admin/skill/plans`）

| moduleId | 能力 |
|---|---|
| `publish_xhs` / `publish_douyin` / `publish_xianyu` | 各平台发布管线 |
| `auto_reply_dm` | 私信半自动回复 |
| `auto_reply_comment` | 自己帖评论半自动回复 |
| `intercept_comment` | 截流评论 |
| `notification` | 推送门铃 |
| `research` | 赛道研究 |
| `daily_report` / `ops_director` / `mkt_director` | 报告与总监 |
| `nurture` / `image_gen` | 养号 / 配图 |

设备端对旧 ID（如 `auto-reply`、`lead-tracking`）有别名兼容，**新建套餐请用上表 snake_case**。

---

## 🕐 定时任务自动配置（新设备部署必做！）

> OpenClaw **2026.6+** 定时任务存在 Gateway/SQLite 里，**不是** `~/.openclaw/cron/jobs.json`。写 jobs.json 不会跑、还会让新设备「配了但没生效」。
>
> **正确入口（按优先级）**
> 1. **管理端**：mno-management → 设备详情「定时任务」→「下发标准包」（MQTT `merge_cron`，设备跑 `openclaw cron add/edit --command`）
> 2. **本机 CLI**：`openclaw cron add --command "…" --no-deliver --timeout-seconds N`（`openclaw automations` 是同一套的别名）
> 3. **禁止**：手写/合并 `cron/jobs.json`；禁止 `agentTurn` + `delivery: silent`（会退化成每 15 分钟往群里汇报）
>
> 设备需 mqtt-reporter **≥1.2.102**（CLI 异步，不堵 MQTT；gateway password 走环境变量 `OPENCLAW_GATEWAY_PASSWORD`）。
>
> ⚠️ **你（Agent）收到「配置定时任务」/「初始化设备」/「部署完成」/「配置线索捕获」时：**
> 1. 启动 `notification-listener.js`（门铃常驻）
> 2. 先 `openclaw cron list --json`。若已有同名标准包且 payload 是 `command`，不要重复 add
> 3. 缺的用 CLI `--command` 补；已有 `agentTurn` 的同名任务先 `openclaw cron rm <id>` 再 add
> 4. **不要**让用户手搓 12 条，**不要**只配一半，**不要**写 jobs.json
> 5. 回复一两句：已用 command 静默任务，不会刷群

### 必装定时任务清单

| ID | 时间 | 脚本 / 动作 | 说明 | 操控屏幕 | `--timeout-seconds` |
|-----|------|------|------|------|------|
| `wiki-sync` | 每天 03:00 | `node scripts/wiki/sync-knowledge.js --since 1` | 知识库增量同步 | ❌ | 180 |
| `wiki-compile` | 每周日 19:30 | `node scripts/wiki/compile-local.js --days 14` | 本地线索+进化 → wiki/local | ❌ | 180 |
| `ops-director` | 每天 08:00 | `node scripts/ops-director.js` | 运营总监晨会（脚本自己推飞书） | ❌ | 180 |
| `daily-report` | 每天 22:00 | `node scripts/daily-report.js` | 数字员工晚报（脚本自己推飞书） | ❌ | 180 |
| `works-xhs` | 每天 21:00 | `node scripts/xhs/creator-analytics-scraper.js` | 小红书创作者中心作品分析 | ✅ 互斥 | 480 |
| `works-douyin` | 每天 21:10 | `node scripts/douyin/creator-analytics-scraper.js` | 抖音创作者中心作品分析 | ✅ 互斥 | 480 |
| `marketing-weekly` | 每周日 20:00 | `node scripts/marketing-director.js` | 营销总监周报（脚本自己推飞书） | ❌ | 180 |
| `track-evolve` | 每周日 19:00 | `node scripts/track/evolve-all.js` | 赛道周进化 | ❌ | 360 |
| `notif-healthcheck` | 每 5 分钟 | 检查并拉起 notification-listener | 门铃自愈 | ❌ | 45 |
| `inbox-xhs` | 每 20 分钟（9–22 点） | `node scripts/xhs/inbox-scraper.js` | 小红书真线索（有新线索才推） | ✅ 互斥 | 300 |
| `inbox-douyin` | 每 15 分钟（9–22 点） | `node scripts/douyin/inbox-scraper.js` | 抖音真线索（有新线索才推） | ✅ 互斥 | 300 |
| `inbox-xianyu` | 每 20 分钟（9–22 点） | `node scripts/xianyu/inbox-scraper.js` | 闲鱼买家会话（有新线索才推） | ✅ 互斥 | 300 |

> inbox 脚本已自检管线锁：管线忙时自动 `pipeline_busy` 跳过，不会抢屏。凌晨不跑（与规则 3 一致）。
>
> **和 OpenClaw 调度对齐（必读）**：
> 1. 必须 `payload.kind: command`（`--command`），**不走 Agent**；`delivery.mode: none`（`--no-deliver`）
> 2. `--session isolated`。command 任务默认墙钟 **10 分钟**；碰屏任务必须带上表的 `--timeout-seconds`
> 3. 命令末尾 `echo NO_REPLY`。脚本日志用 `tee -a`，不要只 `>> logfile`（调度器看不到输出会当卡死）
> 4. **禁止** `agentTurn`。旧设备 list 里若 `kind` 不是 command，删掉重建
> 5. 核对：`openclaw cron list --json`，不要打开 `jobs.json`

### CLI 示例（缺哪条补哪条；名称必须与上表一致，管理端按名对齐）

```bash
openclaw cron add \
  --name "📬 抖音私信扫描" \
  --cron "*/15 9-22 * * *" \
  --tz Asia/Shanghai \
  --session isolated \
  --agent main \
  --wake now \
  --no-deliver \
  --timeout-seconds 300 \
  --command 'mkdir -p "$HOME/openclaw/workspace/logs" && cd "$HOME/openclaw/workspace/skills/android-worker-node" && set -o pipefail; node scripts/douyin/inbox-scraper.js 2>&1 | tee -a "$HOME/openclaw/workspace/logs/inbox-douyin.log"; echo NO_REPLY'
```

完整 12 条定义以 skill 内 `scripts/cron-defaults.js` 为准（管理端「下发标准包」读这份）。

> **Agent 行为**：
> 1. 优先请老板点管理端「下发标准包」；本机有 CLI 权限则自己 `cron add/edit`
> 2. 立刻启动门铃进程（启动本身不推飞书）
> 3. 回复：「定时任务已用静默 command，不会往群里刷扫描汇报」
> 4. Gateway 过旧不认 `--command`：先升级 OpenClaw；不要用 agentTurn 兜底刷群

---

## 📚 Wiki 知识系统（LLM Wiki 模式）

设备端维护一个本地知识库（`wiki/` 目录），以 Markdown 文件形式存储，是运营总监和营销总监的决策基础。

### 目录结构

```
wiki/
├── INDEX.md                     # 自动生成的索引页
├── industry/                    # 行业知识（从服务端拉取并编译）
│   ├── 美业_xhs.md             # 美业在小红书的运营知识
│   └── 教培_douyin.md           # 教培在抖音的运营知识
├── decisions/                   # 运营总监决策记录（每日一个）
│   └── 2026-07-08.md
├── tracks/                      # 赛道分析（evolve 生成）
│   └── 美甲赛道.md
└── reports/                     # 营销总监报告
    ├── 周报_2026-07-06.md
    └── 月报_2026-07-01.md
```

### 知识同步

```bash
# 全量同步（首次部署）
node scripts/wiki/sync-knowledge.js

# 增量同步（每天 cron 自动跑）
node scripts/wiki/sync-knowledge.js --since 1
```

### 知识上报（设备发现新知识）

当赛道 evolve 分析中发现有价值的新知识时，调用 `reportKnowledge()` 写入事件文件，mqtt-reporter 自动上报到服务端入库，其他设备下次同步时可拉到。

> **Wiki 的核心价值**：让 Agent 的决策不是每次从零开始，而是站在之前所有经验之上。

发文管线会读本机 `wiki/tracks` + `wiki/local` + 昨日决策 + 进化 JSON（高效/低效/标题示例）。**不要**把舰队 `wiki/industry` 当主知识——会串台。设备损坏后的资产靠 **按 SN 的 wiki 快照**（`/device/wiki-snapshot` + MQTT `wiki_snapshot`），不是 `knowledge/sync`。

---

## 🧠 运营总监 / 营销总监 / Wiki（卡片优先）

cron 到点会自己跑并推飞书卡片。

- **运营总监建议卡**：只有审批按钮「执行建议 / 再分析 / 先不执行」。执行后再选发小红书/抖音/闲鱼。
- **功能菜单**（周报、进化、同步）：只有用户要菜单，或 `skill-cmd.js --send-menu`，不要钉在建议卡上。

用户侧：

- 建议卡点审批按钮；功能入口走菜单
- **指定平台、指定赛道、改计划** 才 @ 你

### Agent 行为

- 用户只说「运营」「菜单」「周报」「wiki」且没有具体约束 → `node scripts/skill-cmd.js --send-menu`
- 用户点了运营/营销/wiki 卡片按钮 → **`NO_REPLY`**，禁止回复「请用发/重新写」
- **「执行建议」≠ 再出今日建议**。那是批准后选平台；禁止再跑 `ops_today`
- 「再分析」才是 `ops_reanalyze` / `ops_today`
- 管线 `pollForReply` 等待时，这些按钮回落文本也不是审批词
- 复杂：`ops-director.js` / `marketing-director.js --days 30` / `evolve-all.js` / `evolve.js --track …`

```bash
node scripts/skill-cmd.js --send-menu
node scripts/skill-cmd.js --run ops_today
node scripts/skill-cmd.js --run mkt_weekly
node scripts/skill-cmd.js --run mkt_monthly
node scripts/skill-cmd.js --run wiki_evolve
node scripts/ops-director.js --dry-run
node scripts/marketing-director.js --days 30 --dry-run
```

> 点「执行建议」后选平台才会开审批发文。不要把「执行建议」再跑成一份今日建议。
---

### 测试 ADB 连接

```bash
node scripts/adb-helper.js
```

### 测试屏幕阅读器

```bash
node scripts/screen-reader.js
```

### 赛道管理 — 生成新赛道（给新客户用）

```bash
# 基础生成（行业 + 城市）
node scripts/track/generate.js --industry 教培 --city 南京 --platform xhs

# 带细分行业和品牌
node scripts/track/generate.js --industry 教培 --city 南京 --platform xhs \
  --sub-industry 少儿编程 --brand 阿波罗机器人 --target "3-12岁孩子家长"

# 带聊天截图分析（更精准 — 推荐！）
node scripts/track/generate.js --industry 教培 --city 南京 --platform xhs \
  --screenshots /path/chat1.jpg,chat2.jpg --sub-industry 少儿编程

# 生成抖音版
node scripts/track/generate.js --industry 教培 --city 南京 --platform douyin
```

从行业模板 + 客户差异化信息 + 聊天截图洞察，自动生成完整赛道 YAML。
**聊天截图越多越精准**：Vision AI 会提取商家成交话术、客户痛点、抗拒点。

#### ⚠️ 新行业赛道攻坚指南（无预设 Demo / 模板时必读！）

系统内置了 4 个行业模板：**教培、医美、装修、餐饮**（在 `scripts/track/templates/` 目录下）。
如果用户要做的行业不在这 4 个中（比如月嫂、法律咨询、宠物、保险、二手设备等），generate.js 会缺少行业骨架参考，**裸跑生成的 YAML 质量不可控**。

**绝对禁止只用行业名词裸跑生成！** 你必须按以下 SOP 操作：

**第 1 步：前置索要素材（最关键！）**

在执行 generate.js 之前，**主动向老板要以下素材**（至少要到一种）：
- 📸 同行爆款笔记/商品的截图（3-5 张）
- 💬 与客户的真实聊天截图（成交记录最佳）
- 📝 老板口述的核心卖点、客户痛点、常见问题

然后把截图通过 `--screenshots` 传入 generate.js，Vision AI 会从中提取话术和痛点，强行捏出"对标 Demo"。

> **话术参考**：「老板，这个行业我们还没有预设模板，你能发几张同行的爆款笔记截图或者你跟客户聊天的截图吗？我用 Vision AI 扫一下就能提取出话术风格，生成的赛道会精准很多。」

**第 2 步：借用最相近的行业模板**

如果实在拿不到截图，用 `--industry` 蹭最接近的已有行业。判断标准是底层逻辑相似（而非表面行业相似）：
- 卖"信任+服务"的（月嫂中介/法律咨询/心理咨询）→ 蹭 `教培`（同样是卖人的专业性）
- 卖"颜值+效果"的（宠物美容/花艺/婚礼策划）→ 蹭 `医美`（同样是卖变化和体验）
- 卖"实用+避坑"的（二手设备/搬家/家电维修）→ 蹭 `装修`（同样是帮客户不花冤枉钱）
- 卖"口碑+场景"的（民宿/酒吧/亲子乐园）→ 蹭 `餐饮`（同样是烟火气和真实体验）

**告知老板你在借用哪个模板的底层逻辑**，生成后再针对性微调。

**第 3 步：生成后强制审核（不可跳过！）**

生成完成后，你**必须**打开生成的 `tracks/xxx.yaml` 文件，重点检查以下字段：

| 检查项 | 合格标准 | 不合格怎么办 |
|---|---|---|
| `persona.role` / `persona.tone` | 像这个行业真人说话，不像 AI | 你来改，改成接地气的表达 |
| `persona.forbidden` | 至少 5 条，且包含该行业的合规红线 | 你来补，参考已有赛道的 forbidden 密度 |
| `content.title.examples` 或 `publish.generation_prompt` 中的范例 | 至少 6 条，有反差感、有钩子、不空泛 | **这是命脉！** 你必须自己编写几条接地气的标题范例塞进去 |
| `content.styles` 或 `publish.content_angles` | 至少 4 种风格/角度，权重合理 | 参考其他赛道的风格结构补齐 |
| `research.competitor_keywords` | 至少 5 个，是用户真的会搜的关键词 | 你来补，想想这个行业的人会搜什么 |

> **原则**：你是数字员工不是脚本执行器。如果大模型生成的内容太虚、太机器人味，你有责任帮老板在 YAML 里手动改好再交差。不能装作没看见！

### 赛道配置 — 平台内容约束（LLM Prompt 必须遵守！）

不同平台对内容格式有不同限制。**生成赛道 YAML 时必须在 `persona.forbidden` 或 `publish.content_rules` 中写入这些约束**，确保 LLM 不会生成违规内容：

#### 闲鱼平台

| 约束 | 原因 | YAML 写法 |
|---|---|---|
| **禁止使用 emoji 表情符号** | 闲鱼是 Flutter 混合栈，通过剪贴板粘贴 emoji 时 UTF-16/UTF-8 编码转换会损坏字符，发布报「不支持表情输入」。闲鱼自带的表情键盘可用，但自动化管道走剪贴板粘贴无法使用。 | `forbidden: ["禁止使用任何emoji表情符号（💰🔥✅等），用文字替代"]` |
| **文末追加 #话题标签** | 管线自动从 `tags` 数组取最多 5 个标签追加到描述末尾（`#OPPO #5GCPE`），提升搜索流量。LLM 文案本身不需要加 # 标签。 | `tags: ["品牌名", "品类词", "卖点词"]` |
| **标题不超过 30 字** | 闲鱼标题字数限制 | `title_max_length: 30` |
| **价格为纯数字** | 管线自动提取数字，LLM 不要在价格里写"元"、"¥"等 | `price` 字段使用纯数字 |

#### ⚠️ 闲鱼图片策略（重要！影响权重）

闲鱼 2026 年的风控已部署**图像指纹比对**和 **AIGC 检测**。纯 AI 生成的图片会被标记为"疑似虚假交易"，导致降权。与抖音/小红书不同，闲鱼对图片真实性要求极高。

**三个平台的图片策略差异：**

| 平台 | AI 全自动出图 | 推荐做法 |
|------|-------------|---------|
| **闲鱼** | ⚠️ 风险高，易降权 | **review 模式 + 用户提供实拍图**，AI 只做修图辅助 |
| **小红书** | ✅ 可以，标记"AI辅助" | 全自动可接受，混入 1 张实拍更好 |
| **抖音** | ✅ 可以 | 全自动无问题 |

**Agent 行为规则：**

当用户要发闲鱼且**没有通过 `--collect-images` 提供图片**时，你应该**主动建议**：

> 「闲鱼平台对图片真实性要求比较高，全 AI 生成的图容易被降权。建议您拍 1-2 张实物照片发到群里，我用 AI 帮您修图美化后再发布，效果会好很多。如果暂时不方便拍照，我也可以用 AI 生成，但曝光可能会受影响。」

**不要强制阻拦**——如果用户明确表示不提供照片，仍然用 AI 生成并正常发布，但在飞书预览中注明「⚠️ 本次使用 AI 生成图片，闲鱼曝光可能受影响」。

#### ⚠️ AIGC 内容合规提醒（2026 年 4 月）

2025 年 9 月《人工智能生成合成内容标识办法》已施行。小红书/抖音均已上线「AI 生成」标识功能，闲鱼通过图像指纹检测。

**当前策略：告知用户，不自动操作标识**

管线**不会**自动在平台上勾选 AI 标识（三个平台的发布流程来之不易，增加 UI 操作步骤会引入不稳定性）。但 Agent 应在以下场景主动告知用户：

- **全自动出图时**（review 模式飞书预览 / full 模式启动通知）：提醒「本次使用 AI 生成图片，建议发布后在平台手动标注 AI 辅助」
- **首次部署给新客户时**：告知三个平台的 AIGC 标识政策，建议客户了解风险

> 💡 **实测经验**：实拍图 + AI 修图（大字报、裁切、调色）**不容易被判定为 AIGC**。全自动 AI 出图才是高风险。所以 review 模式 + 用户提供实拍图是最安全的路线。

#### 小红书平台

| 约束 | 原因 | YAML 写法 |
|---|---|---|
| emoji 可正常使用 | 小红书原生界面，剪贴板粘贴 emoji 无编码问题 | 无需限制 |
| 标题不超过 20 字 | 小红书标题字数限制 | `title_max_length: 20` |
| 正文建议 300-800 字 | 太短没曝光，太长没人看 | `content_length: "300-800"` |

#### 抖音平台

| 约束 | 原因 | YAML 写法 |
|---|---|---|
| emoji 可正常使用 | 抖音原生界面，粘贴无问题 | 无需限制 |
| 标题不超过 30 字 | 抖音标题字数限制 | `title_max_length: 30` |
| 正文建议 200-500 字 | 图文笔记的描述 | `content_length: "200-500"` |

> ⚠️ **闲鱼赛道特别提醒**：如果你在生成闲鱼赛道的 YAML 时发现模板里没有 `forbidden: ["禁止emoji"]` 这条约束，**你必须手动加上**。否则 LLM 会在文案末尾加 💰💡🔥 等 emoji，导致发布时报错。管线虽然有兜底清除逻辑，但上游约束才是正解。

### 内容新鲜度（老板不用手配！）

运营一个月后文案容易同质化。系统已内置三层，**不要让老板去改 YAML / 扩角度**：

| 层 | 谁做 | 干什么 |
|---|---|---|
| 每次生成 | `llm-client` 自动 | 读本平台已发标题做黑名单；`content_angles` 轮转；标题去重拦截 |
| 每周日 19:00 | cron `track-evolve` → `evolve-all.js` | 扫 `tracks/` 全部赛道，检测同质化 → 建议新角度/新标题示例 → 飞书请老板回「发」写回 |
| 部署时 | Agent | 把 `track-evolve` 写进必装 cron（与 inbox/总监同批） |

老板日常只需：周日看到「赛道进化写回确认」时回 **「发」** 或 **「取消」**。不要手搓 angles。

> Agent：若 cron 里没有 `track-evolve`，在「配置定时任务 / 初始化设备」时补上。已有设备也可主动合并写入，无需等老板开口。

### 赛道管理 — 赛道优化（自动周跑；也可手动）

```bash
# ✅ 推荐：扫全部赛道（cron 默认跑这个）
node scripts/track/evolve-all.js --period 14

# 单个赛道
node scripts/track/evolve.js --track tracks/education-xhs.yaml --period 14

# 只分析不写回
node scripts/track/evolve-all.js --dry-run
node scripts/track/evolve.js --track tracks/xxx.yaml --no-writeback
```

根据真线索归因 + 发布记录分析高转化模式；检测标题同质化时会强制建议 `new_content_angles` / `new_title_examples`。
默认推飞书摘要；老板回「发」则安全补丁写回赛道 YAML（风格权重/关键词/标签/发布时间/**新角度**/标题示例等白名单字段，先备份 `.bak`）。
**数据来源是 lead_event / inbox + attribution，不需要抓取平台前端。**

### 冒烟自检（装机/发版前）

```bash
cd ~/openclaw/workspace/skills/android-worker-node
# 默认 device：单测 + ADB + App 安装 + 门铃进程 + 管线锁
node scripts/smoke-check.js
# 仅逻辑
node scripts/smoke-check.js --level logic
# 完整：+ 线索统计 + 权益 + dry-run 挑线索
node scripts/smoke-check.js --level full
# 结果推飞书
node scripts/smoke-check.js --level full --feishu
```

报告落在 `memory/smoke/`（`LATEST.md` / `LATEST.json` + 带时间戳历史）。**不抢管线锁**；管线忙时会 warn。  
真机点屏发帖/回复不在冒烟范围——用各脚本 `--dry-run` 或人工发一条验收。

### 本地 Wiki 编译

```bash
node scripts/wiki/compile-local.js
node scripts/wiki/compile-local.js --days 14
```

把近期线索快照 + 进化报告编译到 `wiki/local/`（与远端 `sync-knowledge.js` 互补）。




## 用户说什么 → 你该怎么做

### 场景 1：用户只说文字，没发图片

| 用户的话 | 你应该运行的命令 |
|---|---|
| "安卓发一篇小红书" / "帮我发个笔记" | `node scripts/xhs/pipeline.js --track tracks/<赛道>.yaml --mode review` |
| "发一篇小红书，出 3 张图" / "要一组图" | 同上，加 `--image-count 3`（没说数字的「多张/一组」也用 3；最多 9） |
| "第一张教室，第二张家长沟通" | 加 `--image-count` + `--image-briefs "1:教室;2:家长沟通"` |
| "全自动发，不用审批" | `node scripts/xhs/pipeline.js --track tracks/<赛道>.yaml --mode full` |
| "先生成个草稿看看" | `node scripts/xhs/pipeline.js --track tracks/<赛道>.yaml --mode draft` |
| "研究一下竞品" / "竞品调研" / "TopN" | `node scripts/xhs/research-scraper.js --keyword "…"`；抖音用 `douyin/research-scraper.js`；或 `--mode research` |
| "安卓养个号" / "刷一会小红书" | `node scripts/xhs/nurture.js --duration 30` |
| "安卓发一篇抖音" / "抖音发个图文" | `node scripts/douyin/pipeline.js --track tracks/<赛道>.yaml --mode review` |
| "发抖音，出 3 张图" | 同上，加 `--image-count 3` |
| "抖音全自动发" | `node scripts/douyin/pipeline.js --track tracks/<赛道>.yaml --mode full` |
| "刷一会抖音" / "抖音养号" | `node scripts/douyin/nurture.js --duration 30`（仅新号推荐） |
| "抖音先养号再发" | `node scripts/douyin/pipeline.js --track tracks/<赛道>.yaml --mode warmup`（仅新号推荐） |
| "发个闲鱼" / "闲鱼挂一个" / "卖闲置" | `node scripts/xianyu/pipeline.js --track tracks/<赛道>.yaml --mode review` |
| "帮我挂个闲鱼" / "闲鱼快速上架" | `node scripts/xianyu/pipeline.js --track tracks/<赛道>.yaml --mode quick-publish --title "商品名" --price 99 --collect-images` |
| "闲鱼全自动发" | `node scripts/xianyu/pipeline.js --track tracks/<赛道>.yaml --mode full` |
| "刷一会闲鱼" / "闲鱼养号" | `node scripts/xianyu/nurture.js --track tracks/<赛道>.yaml --count 10`（仅新号推荐） |
| "闲鱼登录" / "登录闲鱼" | `node scripts/xianyu/pipeline.js --mode login` |
| "开始通知监听" / "启动门铃" / "线索监控" | 启动 notification-listener + 确保 notif-healthcheck cron |
| "配置线索捕获" / "配置定时任务" / "初始化设备" / "部署完成" | **启动门铃** + 管理端下发标准包或 `openclaw cron add --command`（禁止写 jobs.json） |
| "扫描私信" / "抓线索" / "看消息" | 串行跑三平台 inbox-scraper（管线忙则跳过） |
| "扫小红书私信" | `node scripts/xhs/inbox-scraper.js` |
| "扫抖音私信" / "扫陌生人消息" | `node scripts/douyin/inbox-scraper.js` |
| "扫闲鱼消息" | `node scripts/xianyu/inbox-scraper.js` |
| "抓作品数据" / "看阅读量" / "看播放量" | `node scripts/xhs/creator-analytics-scraper.js` + `node scripts/douyin/creator-analytics-scraper.js` |
| "回复私信" / "半自动回复" / "跟进线索" | 未指定平台时跑 `xhs/dm-reply.js`；可再跑抖音/闲鱼 |
| "回复小红书私信" | `node scripts/xhs/dm-reply.js` |
| "回复抖音私信" / "跟进抖音线索" | `node scripts/douyin/dm-reply.js` |
| "回复闲鱼私信" / "跟进闲鱼买家" | `node scripts/xianyu/dm-reply.js` |
| "回复指定线索" | 对应平台 `dm-reply.js --lead-id …` |
| "回复评论" / "跟进评论" | 未指定先 `xhs/comment-reply.js`，可再 `douyin/comment-reply.js` |
| "回复抖音评论" | `node scripts/douyin/comment-reply.js` |
| "截流" / "热帖留言" / "截流评论" | 问清平台；小红书 `xhs/intercept-comment.js --keyword`；抖音 `douyin/intercept-comment.js --keyword` |
| "运营菜单" / "运营" / "周报" / "wiki"（无具体约束） | `node scripts/skill-cmd.js --send-menu`（让用户点按钮） |
| "优化赛道" / "赛道进化" / "evolve" / "文案总重复" / "内容太像" | 无指定赛道：`node scripts/skill-cmd.js --run wiki_evolve`；单赛道才用 `evolve.js --track …` |
| "编译本地 wiki" / "整理知识页" | `node scripts/skill-cmd.js --run wiki_compile` |
| "冒烟" / "自检" / "测一下设备" | `node scripts/smoke-check.js`；完整加 `--level full` |
| "同步知识库" / "拉取知识" | `node scripts/skill-cmd.js --run wiki_sync` |
| "今天干什么" / "运营建议" / "运营分析" | `node scripts/skill-cmd.js --run ops_today` |
| "出个周报" / "本周数据怎么样" | `node scripts/skill-cmd.js --run mkt_weekly` |
| "出个月报" / "本月数据" | `node scripts/skill-cmd.js --run mkt_monthly` |

### 场景 2：用户发了图片 + 文字要求（最常见！）

**用户发了图：加 `--collect-images`。处理意见加 `--image-actions` / `--cover-text`。内容主题进 `--instruction`。**  
**用户没发图但要 N 张 AI 图：加 `--image-count N`。有画面要求再加 `--image-briefs`。不要改 YAML。**

**小红书和抖音用法完全一致：**

```bash
# 用户发了图片 + 说"介绍机构信息，第一张做封面，第二张原图，大字写春季招生"

# 小红书
node scripts/xhs/pipeline.js \
  --track tracks/<赛道>.yaml \
  --mode review \
  --collect-images \
  --instruction "介绍机构信息，做宣传，引导家长试听" \
  --image-actions "1:ai_cover;2:original" \
  --cover-text "春季招生"

# 抖音（完全相同的参数格式）
node scripts/douyin/pipeline.js \
  --track tracks/<赛道>.yaml \
  --mode review \
  --collect-images \
  --instruction "介绍机构信息，做宣传，引导家长试听" \
  --image-actions "1:ai_cover;2:original" \
  --cover-text "春季招生"
```

管线内部会：
1. 用 `--instruction` 写主题文案
2. 用 `--image-actions` 处理实拍（封面叠字 / 原图直发）
3. 用 `--cover-text` 把用户指定的大字叠上去 / 写进 AI 封面

> **重要**：除非用户明确说"全自动"或不需要审核，否则默认使用 `--mode review`（审批模式）。

### 场景 3：用户只发了图片，没有文字

```bash
# 加 --collect-images 收集图片，不加 --instruction（管线自动选题）
node scripts/xhs/pipeline.js \
  --track tracks/<赛道>.yaml \
  --mode review \
  --collect-images
```

### 场景 4：用户要求同时发小红书和抖音

**必须分两次运行，不能同时跑！** 因为同一台设备同时只能操控一个 App。

```bash
# 先发小红书
node scripts/xhs/pipeline.js --track tracks/<赛道>.yaml --mode review \
  --collect-images --instruction "用户要求..."

# 等小红书发布完成后，再发抖音
node scripts/douyin/pipeline.js --track tracks/<赛道>.yaml --mode review \
  --collect-images --instruction "用户要求..."
```

---

## 日志回传说明

用户有时会要求"回传 skill 原始日志"。管线的所有日志都直接输出到 stdout/stderr。

**回传方式**：把命令执行的最后 50-100 行输出贴回飞书群即可。管线日志格式为：
```
[HH:MM:SS] ✅/❌/⚠️/ℹ️ 具体消息内容
```

如果需要完整日志，建议运行时重定向到文件：
```bash
node scripts/douyin/pipeline.js --track tracks/<赛道>.yaml --mode review 2>&1 | tee /tmp/pipeline.log
```

---

## 前置环境说明（给你理解背景用的）

### 设备架构
- **设备**：Radxa ROCK 4D（RK3576, 12GB RAM, UFS 128GB）
- **运行环境**：Termux 内的 Node.js + OpenClaw
- **远程方式**：SSH 连接到设备（ADB over WiFi）
- **显示**：HDMI 外接显示器 1920×1080
- **注意**：设备没有摄像头，抖音可能弹出权限提示，管线会自动处理

### 技术分层

| 层 | 技术 | 用途 |
|---|---|---|
| **UIAutomator 层**（主力） | adb shell uiautomator dump | 控件树解析，精准定位按钮/输入框 |
| **ADB 操控层** | adb shell input swipe | 模拟点击/滑动（用 swipe 替代 tap 防检测） |
| **Qwen Vision 层**（兜底） | Qwen 3.5 Plus Vision API | 极少场景（验证码、异形弹窗） |
| **飞书通信层** | 飞书 Open API | 草稿预览推送、审批回复轮询、图片接收、通知转推 |
| **发布流程** | ADB push 图片 → 操控 App UI | 选图 → 填标题正文 → 加标签 → 发布 |

### 图片顺序规则
- `--images` 传入的图片数组顺序就是最终发布时选图的顺序
- **第一张 = 封面图**（小红书和抖音都适用）
- 管线会按数组顺序将图片推送到设备，在相册中按时间排序后依次选择
- 所以你在构造 `--images` 时，务必把封面图放在第一个位置

### 防封机制（已内置，不需要你额外处理）
- 所有点击用 `input swipe` 短距模拟（不用 `input tap`，防 FLAG_TAINTED 检测）
- 文字输入模拟人类打字速度 + 2% 随机错字退格（"结巴打字"）
- 操作间隔随机化（1.5-4 秒）
- 浏览停留随机化（5-25 秒）
- 活跃时段限制（8:00-23:00）
- 深夜不操作（0:00-7:00 挂起）
- 一机一号，真实硬件
- 【抖音专属】发布频率限制（每日≤2篇，间隔≥4h）

### 进程防冲突机制（已内置）
- 管线启动时会自动获取进程锁（PID 文件锁）
- 如果有另一个管线进程在运行，新进程会**自动拒绝启动**并给出提示
- 你不需要手动检查是否有其他进程在跑，管线会自己处理

---

## 项目文件说明

```
android-worker-node/
├── scripts/
│   ├── adb-helper.js            # ADB 设备操控（点击/滑动/截图/启动App）
│   ├── screen-reader.js         # UIAutomator 控件树解析（主力定位）
│   ├── anti-detect.js           # 拟人化反检测策略库
│   ├── llm-client.js            # LLM：中转站优先（Pro→主模型∩已配置）→ Vertex/Gemini/Qwen 应急
│   ├── qwen-vision.js           # Qwen Vision AI 截图识别（兜底）
│   ├── shared.js                # 共享模块加载器（LLM/图片/飞书/轮询）
│   ├── utils.js                 # 工具函数（日志/进程锁/路径常量/上报函数）
│   ├── feishu-notify.js         # 飞书通知推送（文本/图片/草稿预览卡片）
│   ├── feishu-poll.js           # 飞书消息轮询（审批回复 + 图片接收）
│   ├── image-gen.js             # AI 图片：自动出图 & 用户给图封面均优先 gpt-image-2（generations / edits）→ Gemini；应急 Vertex/叠字
│   ├── probe-image-gen.js       # 图片模型实机探针（每模耗时/成败）
│   ├── ensure-relay-dns.js      # 修复 fake-ip 导致的中转域名解析失败（需 root）
│   ├── mqtt-reporter.js         # MQTT 远程管理（心跳/事件上报/远程命令/ADB自动重连）
│   ├── openclaw-health.js       # OpenClaw doctor/深度诊断/配置备份回滚（~/.openclaw/）
│   ├── notification-listener.js # 推送门铃（logcat；入 verify_queue）
│   ├── notification-patterns.js # 各平台推送文案信号表
│   ├── verify-queue.js          # 门铃 → inbox 核实队列
│   ├── inbox-common.js          # App 内会话解析/分类公共逻辑
│   ├── works-metrics.js         # 自有作品曝光解析/落盘
│   ├── creator-analytics.js     # 创作者中心识页+作品分析解析
│   ├── diagnose-creator-common.js # 创作者路径探测公共（findTapTarget）
│   ├── attribution.js           # 发布/线索归因 ID
│   ├── daily-report.js          # 每日晚报（数据汇总 → 飞书推送）
│   ├── smoke-check.js           # 冒烟自检（分层 + memory/smoke 日志）
│   ├── ops-director.js          # 🧠 运营总监（Wiki+数据 → LLM分析 → 飞书审批）
│   ├── marketing-director.js    # 📊 营销总监（周报/月报 → LLM分析 → 飞书推送）
│   ├── wiki/                    # Wiki 知识系统
│   │   ├── sync-knowledge.js    # 从服务端拉取知识 → 编译本地 Markdown
│   │   └── compile-local.js     # 本地线索+进化报告 → wiki/local/
│   ├── track/                   # 赛道管理
│   │   ├── generate.js          # 赛道生成器（行业+素材→YAML）
│   │   ├── evolve.js            # 赛道进化器（单文件：分析→飞书确认→YAML 写回）
│   │   ├── evolve-all.js        # 批量进化（cron 周跑：扫 tracks/）
│   │   └── templates/           # 行业基础模板
│   │       ├── education.yaml   # 教培
│   │       ├── beauty.yaml      # 医美
│   │       ├── renovation.yaml  # 装修
│   │       ├── food.yaml        # 餐饮
│   │       └── xianyu-generic.yaml # 闲鱼通用
│   ├── xhs/                     # 小红书专用
│   │   ├── pipeline.js          # 全自动/审批/草稿管线
│   │   ├── operator.js          # 小红书操作逻辑
│   │   ├── nurture.js           # 养号任务
│   │   ├── inbox-scraper.js     # App 内私信扫描（真线索）
│   │   ├── works-scraper.js     # 已停用（主页网格无效）
│   │   ├── creator-analytics-scraper.js # 创作者中心作品分析（唯一数据源）
│   │   ├── diagnose-creator-analytics.js # 创作中心路径探测
│   │   ├── dm-reply.js          # 半自动私信（草稿→飞书确认→发送）
│   │   ├── comment-reply.js     # 半自动评论回复（自己帖）
│   │   ├── intercept-comment.js # 半自动截流评论（他人帖）
│   │   └── research-scraper.js  # 竞品 TopN 深挖（互动+正文）
│   ├── douyin/                  # 抖音专用
│   │   ├── pipeline.js          # 全自动/审批/草稿/warmup管线
│   │   ├── operator.js          # 抖音操作逻辑（状态机驱动）
│   │   ├── nurture.js           # 养号任务（推荐流+垂类搜索）
│   │   ├── inbox-scraper.js     # App 内私信扫描（含陌生人盒）
│   │   ├── works-scraper.js     # 已停用（主页网格无效）
│   │   ├── creator-analytics-scraper.js # 创作者中心作品分析（唯一数据源）
│   │   ├── diagnose-creator-analytics.js # 创作者中心路径探测
│   │   ├── dm-reply.js          # 半自动私信（含陌生人盒）
│   │   ├── comment-reply.js     # 半自动评论回复
│   │   ├── intercept-comment.js # 半自动截流评论
│   │   └── research-scraper.js  # 竞品 TopN 深挖
│   └── xianyu/                  # 闲鱼专用
│       ├── pipeline.js          # 全自动/审批/快速发布/草稿管线
│       ├── operator.js          # 闲鱼操作逻辑（UIAutomator+Vision混合）
│       ├── nurture.js           # 养号任务（推荐流+搜索浏览）
│       ├── inbox-scraper.js     # App 内买家会话扫描
│       └── dm-reply.js          # 半自动买家私信
├── tracks/                      # 赛道配置 YAML 文件（客户的商业资产）
├── wiki/                        # LLM Wiki 知识库（本地 Markdown）
├── package.json
└── SKILL.md                     # 你正在看的这个文件
```

---

## MQTT 远程管理（mqtt-reporter）

### 概述

`mqtt-reporter.js` 是一个**独立旁路进程**，通过 MQTT 协议将设备状态实时上报到云端管理平台，并接收远程控制命令。它与管线（pipeline）、通知监听（notification-listener）完全解耦，三者互不依赖，互不影响。

```
┌───────────────────────────────────────────┐
│ 设备端 Termux                              │
│                                           │
│  ┌──────────────────┐  独立进程            │
│  │ openclaw gateway │  （Agent 核心）      │
│  └──────────────────┘                     │
│                                           │
│  ┌──────────────────┐  独立进程            │
│  │ mqtt-reporter.js │  （远程管理旁路）    │
│  └────────┬─────────┘                     │
│           │ MQTT                          │
│  ┌──────────────────┐  独立进程            │
│  │ notification-    │  （通知监听）        │
│  │ listener.js      │                     │
│  └──────────────────┘                     │
│                                           │
│  ┌──────────────────┐  按需启动            │
│  │ pipeline.js      │  （发布管线）        │
│  └──────────────────┘                     │
└───────────────────────────────────────────┘
          │ MQTT
          ▼
┌──────────────────────┐
│ Aedes Broker         │
│ broker.mnoiot.com    │
└──────────┬───────────┘
           ▼
┌──────────────────────┐
│ mno-management       │  管理后台
│ mno_new / H5         │  微信 H5
└──────────────────────┘
```

### 核心职责

| 功能 | 频率 | 说明 |
|------|------|------|
| 心跳上报 | 120 秒/次 | CPU、内存、电池、ADB 连接状态（含自动重连）、OpenClaw 运行状态、设备型号 |
| 配置快照上报 | 连接时 + 配置变更后 | 上报 `~/.openclaw/openclaw.json` 的脱敏快照 |
| 赛道文件列表上报 | 连接时 + 约每 10 分钟心跳 + 远程触发 | skill `tracks/` 下 YAML 文件名；完整 YAML 需 upload / generate 入库 |
| 管线状态上报 | 管线启停时 | 当前管线是否繁忙、正在执行什么任务 |
| 接收远程命令 | 实时 | 配置更新、ADB 诊断、截屏、停止管线、重启等 |
| LWT 离线通知 | 异常断连时 | MQTT 遗嘱消息自动标记设备离线 |

#### ADB 连接检测（心跳内自动重连）

设备重启后 ADB 不会自动出现在 `adb devices` 列表中，需要先 `adb connect localhost:<端口>`。
心跳检测时会自动尝试重连（读取上次成功端口 → 5555 → 5554），连上后用 `shell echo` 验证真实连通。

#### OpenClaw 状态检测（多层探测）

| 探测方式 | 适用场景 |
|----------|----------|
| `sv status openclaw` | runit 新设备 |
| `tmux list-sessions \| grep openclaw` | tmux 守护的老设备 |
| `pgrep -f "openclaw/gateway/node.*gateway"` | 进程名匹配 |
| `ps \| grep openclaw` | Termux pgrep 异常时的最终兜底 |

### 与管线的关系

> ⚠️ **mqtt-reporter 和管线是完全独立的进程，不共享任何状态。**

| 特性 | mqtt-reporter | pipeline.js |
|------|--------------|-------------|
| 生命周期 | 常驻后台，开机自启 | 按需执行，完成后退出 |
| 互斥性 | 无，不操控屏幕 | 是，同一时间只能运行一个 |
| 依赖 | 仅 mqtt 库 | skill 的全部模块 |
| 配置文件 | 读取 `openclaw.json`（只读上报） | 读写 `openclaw.json` |
| SN 存储 | `~/.openclaw/mno_device.json` | 不关心 |

### SN（设备编号）分配

每台设备有一个唯一的 SN（Serial Number），格式为 `OC` + `YYMMDD` + `3位序号`，例如 `OC260501001`。

SN 通过管理后台（mno-management）批量创建，然后在设备上首次运行时传入：

```bash
# 首次分配（只需一次，SN 会持久化到 mno_device.json）
node scripts/mqtt-reporter.js --sn OC260501001

# 之后每次启动自动读取，无需再传
node scripts/mqtt-reporter.js
```

SN 存储在 **`~/.openclaw/mno_device.json`**（独立文件，不写入 `openclaw.json`）：
```json
{
  "sn": "OC260501001",
  "assignedAt": "2026-05-01T15:00:00.000Z"
}
```

### 启动 mqtt-reporter

mqtt-reporter 通过 tmux 守护运行，已集成到 `termux_boot_start` 开机脚本，设备启动后自动拉起：

```bash
# 手动启动（调试用）
cd ~/openclaw/workspace/skills/android-worker-node
node scripts/mqtt-reporter.js

# 生产模式（tmux 守护 + 日志 + 自动重启）
tmux new-session -d -s mqtt-reporter \
  'while true; do node scripts/mqtt-reporter.js >> ~/openclaw/workspace/logs/mqtt-reporter.log 2>&1; sleep 10; done'
```

### 停止 mqtt-reporter

```bash
tmux kill-session -t mqtt-reporter
```

### 查看 mqtt-reporter 状态

```bash
# 检查 tmux 会话
tmux ls | grep mqtt-reporter

# 查看最近日志
tail -30 ~/openclaw/workspace/logs/mqtt-reporter.log

# 查看 SN
cat ~/.openclaw/mno_device.json
```

### 远程命令列表

mqtt-reporter 接收来自管理平台的 MQTT 命令（topic: `openclaw/{SN}/cmd`），支持以下操作：

| action | 说明 | payload | 影响管线？ |
|--------|------|---------|--------|
| `update_config` | 更新 openclaw.json 的某个字段 | `{ path: "models.providers.bailian.apiKey", value: "sk-xxx" }` | ⚠️ 改配置后需重启 gateway 生效；拒绝写入含 `****` 的脱敏值 |
| `replace_config` | 替换 openclaw.json 的某个区块；`data: null` 删除该键；对象段与旧配置合并 | `{ section: "models.providers.relay-1", data: {...} }` | ⚠️ 写前自动备份；密钥缺失/`****` 保留；损坏配置拒绝写入；禁止清空受保护段/空 models；缺 `data` 不当删除 |
| `restore_config` | **一键抢救**：从 `~/.openclaw/openclaw.json.bak` / config-history 恢复 | 无 | ⚠️ 恢复后需重启 gateway |
| `backup_config` | 立刻备份当前 openclaw.json 到 `.bak` + `config-history/` | 无 | ❌ 不影响 |
| `rollback_config` | 回滚到指定本地备份 | `{ file: "openclaw.json.bak" }` 可选 | ⚠️ 需重启 gateway |
| `report_config` | 强制上报完整配置快照（含 hash / 备份列表元数据） | 无 | ❌ 不影响 |
| `health_probe` | 轻量健康探针：doctor + channels + configHash | 无 | ❌ 不影响 |
| `openclaw_doctor` | 跑 `openclaw doctor`，上报诊断包 | `{ full: true }` 可选 | ❌ 通常不停服 |
| `openclaw_deep_diagnose` | **sv stop → 前台短跑 gateway 采日志 → sv start** | `{ gatewaySeconds: 45 }` | ⚠️ 短暂中断 gateway |
| `list_config_backups` | 列出本地配置备份 | 无 | ❌ 不影响 |
| `adb_diagnose` | 执行 ADB 设备诊断 | 无 | ❌ 不影响 |
| `screenshot` | 截取当前屏幕 | 无 | ❌ 不影响 |
| `list_tracks` | 重新上报赛道列表 | 无 | ❌ 不影响 |
| `kill_pipeline` | 强制停止当前管线 | 无 | ⚠️ 终止运行中的管线 |
| `restart_agent` | 重启 openclaw gateway（sv / tmux）；无进程管理器时拒绝裸 kill | 无 | ⚠️ 会短暂中断 gateway |
| `execute_sop` | 异步执行云端下发的 SOP 流程 | `{ executionId, sopId, steps: [...] }` | ⚠️ SOP 会拉起管线操控屏幕 |
| `update_entitlement`| 热更新本地权益套餐缓存 | `{ planId, enabledModules, expireDate }` | ❌ 不影响 |
| `fix_feishu_messaging` | 飞书按需修复：写 `plugins.entries.feishu.enabled=true` + `plugins install --force`；仅 coding 才改 `full`；**不改群白名单** | 无 | ⚠️ 会重启 gateway |
| `collect_support_bundle` | **不停服**拉取支持包（findings/日志/CLI/备份列表）上报云端，交付后远程排障用 | `{ reason }` 可选 | ❌ 不停服 |

> ⚠️ **`update_config` / `replace_config` 写前会备份到 `~/.openclaw/openclaw.json.bak`（另保留最近 15 份历史于 `~/.openclaw/config-history/`）**。修改后需重启 gateway 生效。若配置写坏，管理后台可发 `rollback_config` / `restore_config` 抢救。

> 🩹 **飞书修复（按需）**：OpenClaw 2026.5+ 飞书是外部包，且必须 `plugins.entries.feishu.enabled=true` 显式信任，否则 `channels.feishu` 配了 Gateway 也不加载。`fix_feishu_messaging` / OTA ensure 会写信任并 `plugins install --force`。

> 🩺 **结构化诊断 `ocHealth.findings`**：健康探针会产出可展示的问题列表（gateway 挂了 / 配置坏了 / 通道插件丢失 / message 工具不可用 / coding profile 等），管理端「诊断结论」直接看，而不是只堆 Doctor 原文。

> 🩺 **健康诊断日志只写 `~/.openclaw/diagnose/`**（Termux HOME 下），不要用 `/tmp`。复杂诊断 UI 在 **mno-management → 小龙虾设备详情**。

> ⚠️ **`kill_pipeline` 会 pkill 所有 pipeline 进程**。这是远程紧急停止用的，正常情况下应通过飞书审批流程控制管线。

### MQTT Topic 说明

| Topic | 方向 | QoS | 说明 |
|-------|------|-----|------|
| `openclaw/{SN}/heartbeat` | 设备→云端 | 0 | 心跳（含 ocHealth 摘要） |
| `openclaw/{SN}/health` | 设备→云端 | 1 | OpenClaw 健康探针（doctor/channels/backups） |
| `openclaw/{SN}/diagnose/report` | 设备→云端 | 1 | doctor / 深度诊断包（含日志尾部） |
| `openclaw/{SN}/config/report` | 设备→云端 | 1 | 配置快照（含 `_configHash` 等元数据） |
| `openclaw/{SN}/pipeline` | 设备→云端 | 1 | 管线状态 |
| `openclaw/{SN}/tracks` | 设备→云端 | 1 | 赛道列表 |
| `openclaw/{SN}/cmd` | 云端→设备 | 1 | 远程命令 |
| `openclaw/{SN}/cmd/ack` | 设备→云端 | 1 | 命令执行回执（含 action/msg） |
| `openclaw/{SN}/sop_step_report` | 设备→云端 | 1 | SOP 执行进度回报 |
| `openclaw/{SN}/consumption` | 设备→云端 | 0 | LLM 算力消耗事件上报 |
| `openclaw/{SN}/knowledge_report` | 设备→云端 | 1 | 设备发现的新知识上报 |
| `openclaw/{SN}/wiki_snapshot` | 设备→云端 | 1 | 本机 LLM wiki 快照（按 SN，返厂可拉回） |

### 前置条件

```bash
# 安装 mqtt 依赖（首次部署）
cd ~/openclaw/workspace/skills/android-worker-node
npm install mqtt
```

### Agent 行为规则

> **mqtt-reporter 对 Agent 透明。** Agent 不需要管理 mqtt-reporter 的启停，不需要知道 SN 是什么，不需要通过 MQTT 做任何操作。mqtt-reporter 是运维层面的旁路进程，由系统管理员（老板）通过微信 H5 或管理后台操控。
>
> Agent 唯一可能涉及的场景：用户问"设备在线吗"或"管理后台能看到这台设备吗"时，可以告知用户检查 `tmux ls | grep mqtt-reporter` 确认进程是否存活。

---

## 飞书配置说明

在 `~/.openclaw/openclaw.json` 的 `channels.feishu` 中配置：

```json
{
  "channels": {
    "feishu": {
      "appId": "cli_xxx",
      "appSecret": "xxx",
      "groupAllowFrom": ["oc_xxx"]
    }
  }
}
```

飞书应用需要以下权限（**应用身份**，开通后须**发布版本**生效）：
- `im:message:send_as_bot` — 发送消息（缺了会收得到、回不去，报 99991672）
- `im:message` — 读取消息（审批轮询用）
- `im:resource` — 下载图片（接收老板发的图片用）
- 建议：`contact:contact.base:readonly` — 解析发送者信息

### 一台应用 vs 多台 Pad（必读）

飞书长连接是**集群模式、不广播**：同一 `appId` 若有多台设备同时连 WebSocket，每条入站事件只会被**随机一台**收到（官方说明，最多 50 连接，不是互踢断线）。

| 场景 | 是否可行 | 做法 |
|------|----------|------|
| **1 台 Pad + 多个飞书群** | ✅ 推荐 | **一个**飞书应用；`groupAllowFrom` 填多个 `oc_…` |
| **多台 Pad，各管各的群/客户** | ❌ 不要共用一个 appId | **每台 Pad 一个飞书应用**（权限清单可复制，但仍须各自创建/发布） |
| 多台 Pad 硬共用一个 appId | ⚠️ 不稳定 | 消息随机落到某台；该台白名单不含此群就会静默丢弃，或答非所问 |

新机开箱：宁可多 10 分钟建应用，也不要用「图省事共用一个 bot」——数字员工是按设备隔离的，飞书入站也必须按设备隔离。

---

## 常见问题

### Q: ADB 连接不上怎么办？
运行 `node scripts/adb-helper.js` 看报错信息。按设备类型处理：
- **Radxa（Root）**：检查 `/data/adb/service.d/enable_adb_tcp.sh` 是否存在且有执行权限。运行 `adb connect localhost:5555`
- **三星/白牌（Non-Root）**：检查 adb-auto-enable App 是否在运行（浏览器访问 `http://localhost:9093`）。如果 WiFi 断了，ADB 也会断——先确认 WiFi 已连接
- **通用**：`adb kill-server && adb devices` 重置后重试

### Q: 设备重启后 ADB 失效？
这是 Android 安全机制导致的。参见上方「ADB 重启持久化」章节配置对应方案。Root 设备配 Magisk 脚本，Non-Root 设备装 adb-auto-enable APK。

### Q: 多个 ADB 设备冲突？
断开多余的：`adb disconnect localhost:5555`，保留 `emulator-5554`。adb-helper.js 会自动选择可用设备。

### Q: 发布失败了怎么办？
管线会自动重试 2 次。如果还是失败，会通过飞书发送截图告警。常见原因：登录过期、App UI 变更、网络问题。

### Q: 需要登录怎么办？
管线检测到未登录时会自动截图推送到飞书。需要在设备上手动完成登录。

### Q: review 模式飞书收不到预览卡片？
检查飞书应用权限是否包含 `im:message:send_as_bot`。检查 `groupAllowFrom` 配置的群 ID 是否正确。

### Q: 通知监听 / 线索捕获没效果？
按顺序排查：
1. **真线索看 inbox，不看推送**：手动跑 `node scripts/xhs/inbox-scraper.js`（或抖音/闲鱼）。若 App 消息页有会话但脚本解析为 0，把截图/日志反馈迭代选择器。
2. **抖音陌生人私信常常没有系统推送**——这是正常的；依赖 `inbox-douyin` cron（每 15 分钟），不要指望门铃 alone。
3. **检查目标 App 是否被系统冻结**：`adb shell am get-standby-bucket com.ss.android.ugc.aweme`（或 xhs/idlefish）。重启 listener 会刷保活策略。
4. **检查门铃进程**：`cat $HOME/.notification-listener.pid && kill -0 $(cat $HOME/.notification-listener.pid) 2>/dev/null && echo 存活 || echo 已死`
5. **检查 cron 是否已注册**：`openclaw cron list --json`，确认有 inbox / notif-healthcheck 且 `kind` 为 `command`。没有 → 管理端「下发标准包」或按「配置定时任务」用 CLI `--command` 补。**不要**打开 `jobs.json`。
6. **管线互斥**：若正在发布，inbox 会打印 `pipeline_busy` 跳过，等发布完下一轮 cron 再扫。

### Q: 用户发了图片但管线没用？
你**必须**在命令中加 `--collect-images` 参数！管线会自动从飞书群下载用户最近发送的图片。**不要**尝试自己保存图片或用 `--images` 手动传路径——Agent 无法直接访问飞书聊天中的图片文件。

### Q: 老板回复了"发"但管线没反应？
可能是飞书群里回复时带了 @机器人名（如 `发@openclaw-android-0322`）。管线已兼容这种格式，但如果仍无反应，让用户单独发一个"发"字（不带 @）试试。
